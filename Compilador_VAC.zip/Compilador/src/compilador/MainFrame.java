package compilador;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import compilerTools.Token;
import compilerTools.ErrorLSSL;

public class MainFrame extends javax.swing.JFrame {

    // Variables de control de archivos y editor
    private Map<JTextPane, File> archivosAbiertos; 
    private Map<JTextPane, Boolean> archivosModificados; 
    private File ultimaRutaArchivo;
    
    // Variables de interfaz adicionales
    private JPopupMenu contextMenu;
    private JMenuItem ctxCopiar, ctxCortar, ctxPegar;
    private JLabel statusLabel;
    private JLabel timeLabel;
    private Timer highlightTimer;
    
    // AUTOCOMPLETADO
    private JPopupMenu autoSuggestionPopup;
    private final String[] KEYWORDS = {
        "cybermain", "start_netrun", "end_netrun", 
        "neural", "floatwave", "datastring", "charbyte", "logic", "synthbyte",
        "if_net", "net_else", "switch_grid", "for_loop", "do_netrun", 
        "while_sync", "repeat_until", "hack_print", "neural_scan", 
        "samurai", "punk", "night", "edgerunner"
    };

    public MainFrame() {
        initComponents(); 
        
        initStatusBar();
        generarAnalizadorLexico();
        crearMenuConfiguracion(); 
        initContextMenu();
        setTitle("PunkSystem v0.1");
        
        // Inicializar popup de autocompletado
        autoSuggestionPopup = new JPopupMenu();
        
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                if (verificarArchivosSinGuardar()) {
                    System.exit(0);
                }
            }
        });

        archivosAbiertos = new HashMap<>();
        archivosModificados = new HashMap<>();
        ultimaRutaArchivo = new File(System.getProperty("user.home"), "Documents");
        
        // Configurar la pestaña inicial
        JScrollPane scrollPaneInicial = (JScrollPane) editorTabs.getComponentAt(0);
        JTextPane editorInicial = new JTextPane();
        
        JTextArea lineNumbersInicial = new JTextArea("1");
        lineNumbersInicial.setBackground(Color.LIGHT_GRAY);
        lineNumbersInicial.setEditable(false);
        lineNumbersInicial.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        SyntaxHighlighter.attachTo(editorInicial);
        addContextMenuToEditor(editorInicial);
        initAutocomplete(editorInicial); // <-- AGREGAR ESTO
       
        highlightTimer = new Timer(300, e -> SyntaxHighlighter.highlight(editorInicial));
        highlightTimer.setRepeats(false);
        
        editorInicial.getDocument().addDocumentListener(new DocumentListener() {
            public void update() {
                highlightTimer.restart();
                SwingUtilities.invokeLater(() -> {
                    try {
                        int lines = editorInicial.getDocument().getDefaultRootElement().getElementCount();
                        StringBuilder sb = new StringBuilder();
                        for (int i = 1; i <= lines; i++) sb.append(i).append("\n");
                        lineNumbersInicial.setText(sb.toString());
                    } catch (Exception e) {}
                    archivosModificados.put(editorInicial, true);
                    updateTabTitle(editorInicial);
                });
            }
            @Override public void insertUpdate(DocumentEvent e) { update(); }
            @Override public void removeUpdate(DocumentEvent e) { update(); }
            @Override public void changedUpdate(DocumentEvent e) { update(); }
        });
        
        editorInicial.addCaretListener(e -> {
            updateStatusBar(editorInicial);
        });
       
        scrollPaneInicial.setViewportView(editorInicial);
        scrollPaneInicial.setRowHeaderView(lineNumbersInicial);
        
        archivosAbiertos.put(editorInicial, null);
        archivosModificados.put(editorInicial, false);
        
        aplicarConfiguracionesGlobales();
        updateMenuStates();
    }
    
    // --- LÓGICA DE AUTOCOMPLETADO ---
    private void initAutocomplete(JTextPane editor) {
        editor.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                // Evitar teclas de navegación y enter
                if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_UP ||
                    e.getKeyCode() == KeyEvent.VK_ENTER || e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    return;
                }
                
                // Mostrar sugerencias al escribir letras
                if (Character.isLetterOrDigit(e.getKeyChar()) || e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
                    checkForSuggestions(editor);
                }
            }
        });
    }

    private void checkForSuggestions(JTextPane editor) {
        String typedWord = getCurrentlyTypedWord(editor);
        if (typedWord.length() < 2) { // Mínimo 2 letras para sugerir
            autoSuggestionPopup.setVisible(false);
            return;
        }

        autoSuggestionPopup.removeAll();
        boolean added = false;

        for (String word : KEYWORDS) {
            if (word.startsWith(typedWord.toLowerCase())) {
                JMenuItem item = new JMenuItem(word);
                item.addActionListener(e -> {
                    replaceWord(editor, typedWord, word);
                    autoSuggestionPopup.setVisible(false);
                });
                autoSuggestionPopup.add(item);
                added = true;
            }
        }

        if (added) {
            try {
                // Calcular posición del popup debajo del cursor
                Point location = editor.modelToView(editor.getCaretPosition()).getLocation();
                SwingUtilities.convertPointToScreen(location, editor);
                autoSuggestionPopup.show(editor, 0, 0); 
                autoSuggestionPopup.setLocation(location.x, location.y + 20);
                editor.requestFocusInWindow(); // Mantener foco en editor
            } catch (Exception e) { }
        } else {
            autoSuggestionPopup.setVisible(false);
        }
    }

    private String getCurrentlyTypedWord(JTextPane editor) {
        try {
            int caretPos = editor.getCaretPosition();
            StyledDocument doc = editor.getStyledDocument();
            int start = caretPos - 1;
            while (start >= 0) {
                String c = doc.getText(start, 1);
                if (!Character.isLetterOrDigit(c.charAt(0)) && !c.equals("_")) {
                    break;
                }
                start--;
            }
            start++;
            return doc.getText(start, caretPos - start);
        } catch (BadLocationException e) {
            return "";
        }
    }

    private void replaceWord(JTextPane editor, String current, String replacement) {
        try {
            int caretPos = editor.getCaretPosition();
            StyledDocument doc = editor.getStyledDocument();
            doc.remove(caretPos - current.length(), current.length());
            doc.insertString(caretPos - current.length(), replacement, null);
        } catch (BadLocationException e) { }
    }
    // --------------------------------

    private void crearMenuConfiguracion() {
        JMenuItem miConfig = new JMenuItem("Configuración");
        menuHerramientas.add(miConfig); 
        
        miConfig.addActionListener(e -> {
            Fuente configDialog = new Fuente();
            configDialog.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent e) {
                    aplicarConfiguracionesGlobales();
                }
            });
            configDialog.setVisible(true);
        });
    }

    private void aplicarConfiguracionesGlobales() {
        ClassArchivoPropiedades props = new ClassArchivoPropiedades();
        String idioma = props.LeerPropiedades("idioma");
        if ("EN".equals(idioma)) {
            jMenu3.setText("File"); jMenu4.setText("Edit");
            menuArchivo.setText("File");
            menuEdicion.setText("Edit");
            menuCompilar.setText("Compile");
            menuHerramientas.setText("Tools");
        } else {
            menuArchivo.setText("Archivo");
            menuEdicion.setText("Edición");
            menuCompilar.setText("Compilar");
            menuHerramientas.setText("Herramientas");
        }
        
        String fontName = props.LeerPropiedades("Fuente");
        String fontSizeStr = props.LeerPropiedades("Tamano");
        String fontStyleStr = props.LeerPropiedades("Estilo");
        
        if (fontName != null && fontSizeStr != null) {
            try {
                Font nuevaFuente = new Font(fontName, Integer.parseInt(fontStyleStr), Integer.parseInt(fontSizeStr));
                for (JTextPane editor : archivosAbiertos.keySet()) {
                    editor.setFont(nuevaFuente);
                    SyntaxHighlighter.highlight(editor); 
                }
            } catch (Exception e) {
                System.out.println("Error aplicando fuente: " + e.getMessage());
            }
        }
    }

    private void addContextMenuToEditor(JTextPane editor) {
        editor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                if (evt.isPopupTrigger()) {
                    contextMenu.show(evt.getComponent(), evt.getX(), evt.getY());
                }
            }
        });
    }

    private void updateStatusBar(JTextPane editor) {
        try {
            int caretPos = editor.getCaretPosition();
            javax.swing.text.Element root = editor.getDocument().getDefaultRootElement();
            int line = root.getElementIndex(caretPos);
            int column = caretPos - root.getElement(line).getStartOffset();
            statusLabel.setText("Línea: " + (line + 1) + ", Columna: " + (column + 1));
        } catch (Exception e) {
            statusLabel.setText("Línea: 1, Columna: 1");
        }
    }

    private void generarAnalizadorLexico() {
        String archivoFlex = System.getProperty("user.dir") + "/src/compilador/CyberpunkLexer.flex";
        String archivoLexicoJava = System.getProperty("user.dir") + "/src/compilador/CyberpunkLexer.java";
        File archivoJava = new File(archivoLexicoJava);
        
        if (archivoJava.exists()) {
            archivoJava.delete();
        }
        
        File archivoFlexFile = new File(archivoFlex);
        if (!archivoFlexFile.exists()) {
            System.out.println("No se encontró el archivo .flex en: " + archivoFlex);
            return;
        }

        try {
            jflex.Main.generate(new String[]{archivoFlex});
            System.out.println("Analizador Léxico generado exitosamente.");
        } catch (Exception ex) {
            System.out.println("***** ERROR DE GENERACION DEL ANALIZADOR LÉXICO *****");
            ex.printStackTrace();
        }
    }

    private void initContextMenu() {
        contextMenu = new JPopupMenu();
        ctxCopiar = new JMenuItem("Copiar");
        ctxCopiar.setIcon(new ImageIcon(getClass().getResource("/icons/copy.png")));
        ctxCopiar.addActionListener(e -> btnCopiarActionPerformed(null));
        
        ctxCortar = new JMenuItem("Cortar");
        ctxCortar.setIcon(new ImageIcon(getClass().getResource("/icons/cut.png")));
        ctxCortar.addActionListener(e -> btnCortarActionPerformed(null));
        
        ctxPegar = new JMenuItem("Pegar");
        ctxPegar.setIcon(new ImageIcon(getClass().getResource("/icons/paste.png")));
        ctxPegar.addActionListener(e -> btnPegarActionPerformed(null));
        
        contextMenu.add(ctxCortar);
        contextMenu.add(ctxCopiar);
        contextMenu.add(ctxPegar);
    }

    private void initStatusBar() {
        statusPanel.setLayout(new BorderLayout());
        JPanel leftPanel = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        statusLabel = new JLabel("Línea: 1, Columna: 1");
        leftPanel.add(statusLabel);
        
        JPanel rightPanel = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));
        timeLabel = new JLabel();
        rightPanel.add(timeLabel);
        
        statusPanel.add(leftPanel, BorderLayout.WEST);
        statusPanel.add(rightPanel, BorderLayout.EAST);
        
        Thread timeThread = new Thread(() -> {
            while (true) {
                SwingUtilities.invokeLater(() -> {
                    timeLabel.setText(new java.text.SimpleDateFormat("HH:mm:ss").format(new java.util.Date()));
                });
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        timeThread.setDaemon(true);
        timeThread.start();
    }

    private void createNewTab(String title, String content, File archivo) {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea lineNumbers = new JTextArea("1");
        lineNumbers.setBackground(Color.LIGHT_GRAY);
        lineNumbers.setEditable(false);
        lineNumbers.setFont(new Font("Monospaced", Font.PLAIN, 12));
      
        JTextPane editor = new JTextPane();
        editor.setText(content);
        
        // --- ACTIVAR AUTOCOMPLETADO EN PESTAÑAS NUEVAS ---
        initAutocomplete(editor);
        // -------------------------------------------------
      
        ClassArchivoPropiedades props = new ClassArchivoPropiedades();
        String fontName = props.LeerPropiedades("Fuente");
        String fontSize = props.LeerPropiedades("Tamano");
        String fontStyle = props.LeerPropiedades("Estilo");
      
        if (fontName != null) {
            editor.setFont(new Font(fontName, Integer.parseInt(fontStyle), Integer.parseInt(fontSize)));
        } else {
            editor.setFont(new Font("Monospaced", Font.PLAIN, 12));
        }
        
        SyntaxHighlighter.attachTo(editor);
        Timer newHighlightTimer = new Timer(300, e -> SyntaxHighlighter.highlight(editor));
        newHighlightTimer.setRepeats(false);
        
        editor.getDocument().addDocumentListener(new DocumentListener() {
            public void updateLines() {
                newHighlightTimer.restart();
                SwingUtilities.invokeLater(() -> {
                    try {
                        int lines = ((StyledDocument) editor.getDocument()).getDefaultRootElement().getElementCount();
                        StringBuilder sb = new StringBuilder();
                        for (int i = 1; i <= lines; i++) sb.append(i).append("\n");
                        lineNumbers.setText(sb.toString());
                    } catch (Exception ex) {
                        int lines = editor.getText().split("\r\n|\r|\n", -1).length;
                        StringBuilder sb = new StringBuilder();
                        for (int i = 1; i <= lines; i++) sb.append(i).append("\n");
                        lineNumbers.setText(sb.toString());
                    }
                });
                archivosModificados.put(editor, true);
                updateTabTitle(editor);
            }
            @Override public void insertUpdate(DocumentEvent e) { updateLines(); }
            @Override public void removeUpdate(DocumentEvent e) { updateLines(); }
            @Override public void changedUpdate(DocumentEvent e) { updateLines(); }
        });
      
        JScrollPane scrollPane = new JScrollPane(editor);
        scrollPane.setRowHeaderView(lineNumbers);
        panel.add(scrollPane, BorderLayout.CENTER);
      
        editorTabs.addTab(title, panel);
        editorTabs.setSelectedComponent(panel);
      
        if (archivo != null) {
            archivosAbiertos.put(editor, archivo);
        }
        archivosModificados.put(editor, false);
    }

    private void updateTabTitle(JTextPane editor) {
        int index = findTabIndexByEditor(editor);
        if (index >= 0) {
            String title = editorTabs.getTitleAt(index);
            File archivo = archivosAbiertos.get(editor);
            Boolean modificado = archivosModificados.get(editor);
            
            String nuevoTitulo = "";
            if (archivo != null) {
                nuevoTitulo = archivo.getName();
            } else {
                 nuevoTitulo = title.replace("*", "");
            }
            
            if (modificado != null && modificado) {
                nuevoTitulo = "*" + nuevoTitulo;
            }
            editorTabs.setTitleAt(index, nuevoTitulo);
        }
    }

    private int findTabIndexByEditor(JTextPane editor) {
        for (int i = 0; i < editorTabs.getTabCount(); i++) {
            JTextPane tabEditor = getEditorFromComponent(editorTabs.getComponentAt(i));
            if (tabEditor == editor) {
                return i;
            }
        }
        return -1;
    }

    private JTextPane getCurrentEditor() {
        int selectedIndex = editorTabs.getSelectedIndex();
        if (selectedIndex >= 0) {
            Component comp = editorTabs.getComponentAt(selectedIndex);
            if (comp instanceof JPanel) {
                JPanel panel = (JPanel) comp;
                for (Component c : panel.getComponents()) {
                    if (c instanceof JScrollPane) {
                        JScrollPane scroll = (JScrollPane) c;
                        return (JTextPane) scroll.getViewport().getView();
                    }
                }
            } else if (comp instanceof JScrollPane) {
                JScrollPane scrollPane = (JScrollPane) comp;
                return (JTextPane) scrollPane.getViewport().getView();
            }
        }
        return null;
    }

    private boolean guardarArchivo(JTextPane editor) {
        File archivo = archivosAbiertos.get(editor);
        if (archivo == null) {
            return guardarArchivoComo(editor);
        } else {
            try {
                Files.write(archivo.toPath(), editor.getText().getBytes());
                archivosModificados.put(editor, false);
                updateTabTitle(editor);
                return true;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error al guardar el archivo", "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
    }

    private boolean guardarArchivoComo(JTextPane editor) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar archivo");
        
        if (ultimaRutaArchivo != null && ultimaRutaArchivo.exists()) {
            fileChooser.setCurrentDirectory(ultimaRutaArchivo);
        } else {
            fileChooser.setCurrentDirectory(new File(System.getProperty("user.home"), "Documents"));
        }
        
        fileChooser.setSelectedFile(new File("nuevo_programa.cpk"));
        fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
            @Override public boolean accept(File f) { return f.isDirectory() || f.getName().toLowerCase().endsWith(".cpk"); }
            @Override public String getDescription() { return "Archivos Cyberpunk (*.cpk)"; }
        });
        
        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            if (!file.getName().toLowerCase().endsWith(".cpk")) {
                file = new File(file.getAbsolutePath() + ".cpk");
            }
            try {
                Files.write(file.toPath(), editor.getText().getBytes());
                archivosAbiertos.put(editor, file);
                archivosModificados.put(editor, false);
                ultimaRutaArchivo = file.getParentFile();
                
                int index = findTabIndexByEditor(editor);
                if (index >= 0) editorTabs.setTitleAt(index, file.getName());
                
                return true;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error al guardar", "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        return false;
    }

    private void abrirArchivo() {
        JFileChooser fileChooser = new JFileChooser();
        ClassArchivoPropiedades props = new ClassArchivoPropiedades();
        String rutaGuardada = props.LeerPropiedades("ruta");
        
        if (rutaGuardada != null && !rutaGuardada.isEmpty()) {
            fileChooser.setCurrentDirectory(new File(rutaGuardada));
        } else {
            fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        }
        
        fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
            @Override public boolean accept(File f) { return f.isDirectory() || f.getName().toLowerCase().endsWith(".cpk"); }
            @Override public String getDescription() { return "Archivos Cyberpunk (*.cpk)"; }
        });

        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try {
                String content = new String(Files.readAllBytes(file.toPath()));
                createNewTab(file.getName(), content, file);
                ultimaRutaArchivo = file.getParentFile();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error al abrir el archivo", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private boolean verificarArchivosSinGuardar() {
        for (int i = 0; i < editorTabs.getTabCount(); i++) {
            JTextPane editor = getEditorFromComponent(editorTabs.getComponentAt(i));
            if (editor != null) {
                Boolean modificado = archivosModificados.get(editor);
                if (modificado != null && modificado) {
                    String nombreTab = editorTabs.getTitleAt(i).replace("*", "");
                    int respuesta = JOptionPane.showConfirmDialog(this, 
                        "El archivo '" + nombreTab + "' tiene cambios sin guardar.\n¿Desea guardarlo antes de salir?", 
                        "Confirmar salida", 
                        JOptionPane.YES_NO_CANCEL_OPTION,
                        JOptionPane.WARNING_MESSAGE);
                    
                    if (respuesta == JOptionPane.YES_OPTION) {
                        if (!guardarArchivo(editor)) return false;
                    } else if (respuesta == JOptionPane.CANCEL_OPTION) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private JTextPane getEditorFromComponent(Component comp) {
        if (comp instanceof JPanel) {
            JPanel panel = (JPanel) comp;
            for (Component c : panel.getComponents()) {
                if (c instanceof JScrollPane) {
                    return (JTextPane) ((JScrollPane) c).getViewport().getView();
                }
            }
        } else if (comp instanceof JScrollPane) {
            return (JTextPane) ((JScrollPane) comp).getViewport().getView();
        }
        return null;
    }

    // ══════════════════════════════════════════════════════════
    // MÉTODO PRINCIPAL DE COMPILACIÓN
    // ══════════════════════════════════════════════════════════
    private void compilarCodigo() {
        JTextPane editor = getCurrentEditor();
        if (editor == null) {
            JOptionPane.showMessageDialog(this, "No hay ningún archivo abierto.");
            return;
        }
        
        if (archivosModificados.get(editor) != null && archivosModificados.get(editor)) {
            if (!guardarArchivo(editor)) return;
        }
        
        File archivo = archivosAbiertos.get(editor);
        if (archivo == null) return;
        
        try {
            // 1. Limpieza de interfaz gráfica y Repositorio Global
            DefaultTableModel tokenModel = (DefaultTableModel) tokenTable.getModel();
            DefaultTableModel symbolModel = (DefaultTableModel) symbolTable.getModel();
            tokenModel.setRowCount(0);
            symbolModel.setRowCount(0);
            resultArea.setText("");

            Repositorio.limpiar(); // ESENCIAL: Borra memoria de la compilación anterior

            // 2. Análisis Léxico
            BufferedReader codigoFuente = new BufferedReader(new FileReader(archivo.getAbsolutePath()));
            CyberpunkLexer lexer = new CyberpunkLexer(codigoFuente);
            Token token;

            while ((token = lexer.yylex()) != null) {
                Repositorio.tokens.add(token);
                if (token.getLexicalComp().startsWith("ERROR")) {
                    String desc = mensajeErrorLexico(token.getLexicalComp(), token.getLexeme());
                    Repositorio.errores.add(new ErrorLSSL(1,
                        desc + " [" + token.getLine() + ", " + token.getColumn() + "]", token));
                }
                if (tokenModel.getRowCount() < 1000) {
                    tokenModel.addRow(new Object[]{
                        token.getLexicalComp(),
                        token.getLexeme(),
                        "[" + token.getLine() + "," + token.getColumn() + "]"
                    });
                }
            }

            // 3. Análisis Sintáctico y Semántico
            if (Repositorio.tokens.size() > 0) {
                // IMPORTANTE: Guardar los tokens originales ANTES de que la gramática los reduzca.
                // El analizador semántico los necesita para poblar la tabla de símbolos de forma robusta.
                ArrayList<Token> tokensOriginales = new ArrayList<>(Repositorio.tokens);

                // Análisis sintáctico (reduce Repositorio.tokens mediante la gramática)
                AnalizadorSintactico sintactico = new AnalizadorSintactico();
                sintactico.Analizar();

                // Análisis semántico (usa tokens originales para tabla de símbolos)
                AnalizadorSemantico semantico = new AnalizadorSemantico(tokensOriginales);
                semantico.Analizar();

                // Llenar tabla de símbolos — 4 columnas: Identificador, Tipo, Valor, Var/Const
                for (Symbol sym : Repositorio.tablaSimbolos.values()) {
                    String strValor    = sym.valor != null ? sym.valor.toString() : "—";
                    String strTipo     = tipoCiberpunk(sym.tipo);
                    String strVarConst = sym.isConst ? "Constante" : "Variable";
                    symbolModel.addRow(new Object[]{sym.id, strTipo, strValor, strVarConst});
                }
            }
            
            // 4. Imprimir resultados y forzar recoloreado
            ImprimirErrores();
            SyntaxHighlighter.highlight(editor);
            
        } catch (Exception e) {
            resultArea.setText("Error crítico durante la compilación:\n" + e.getMessage());
            e.printStackTrace();
        }
    }

    private String mensajeErrorLexico(String tipoError, String lexema) {
        switch (tipoError) {
            case "ERROR_CADENA_SIN_CERRAR":
                return "Error Léxico: Cadena de texto sin cerrar: " + lexema;
            case "ERROR_ENTERO_CERO":
                return "Error Léxico: Entero con cero a la izquierda: '" + lexema + "'";
            case "ERROR_FLOTANTE_CERO":
                return "Error Léxico: Flotante con cero a la izquierda: '" + lexema + "'";
            case "ERROR_IDENTIFICADOR":
                return "Error Léxico: Identificador no puede comenzar con '_': '" + lexema + "'";
            case "ERROR_IDENTIFICADOR_NUMERICO":
                return "Error Léxico: Identificador no puede comenzar con número: '" + lexema + "'";
            case "ERROR_CARACTER_INVALIDO":
                return "Error Léxico: Carácter inválido: '" + lexema + "'";
            default:
                return "Error Léxico: Token no reconocido: '" + lexema + "'";
        }
    }

    private String tipoCiberpunk(String tipoInterno) {
        switch (tipoInterno) {
            case "INT":         return "neural";
            case "FLOAT":       return "floatwave";
            case "STRING_TYPE": return "datastring";
            case "CHAR_TYPE":   return "charbyte";
            case "BOOL_TYPE":   return "logic";
            case "BYTE_TYPE":   return "synthbyte";
            default:            return tipoInterno;
        }
    }

    public void ImprimirErrores() {
        if (Repositorio.errores.size() > 0) {
            resultArea.append("\n=== ERRORES DETECTADOS ("+Repositorio.errores.size()+") ===\n");
            for (ErrorLSSL error : Repositorio.errores) {
                resultArea.append(error.toString() + "\n");
                if (error.getLine() > 0) {
                    highlightErrorLine(getCurrentEditor(), error.getLine());
                }
            }
        } else {
            resultArea.append("\n=== COMPILACIÓN EXITOSA ===\n");
            resultArea.append("El programa no contiene errores léxicos, sintácticos ni semánticos.\n");
        }
    }

    private void highlightErrorLine(JTextPane editor, int lineNumber) {
        if (editor == null || lineNumber < 1) return;
        try {
            StyledDocument doc = editor.getStyledDocument();
            javax.swing.text.Element root = doc.getDefaultRootElement();
            if (lineNumber > root.getElementCount()) return;
            
            javax.swing.text.Element line = root.getElement(lineNumber - 1);
            int start = line.getStartOffset();
            int end = line.getEndOffset();
            
            SimpleAttributeSet compileErrorAttr = new SimpleAttributeSet();
            StyleConstants.setBackground(compileErrorAttr, new Color(255, 200, 150)); 
            StyleConstants.setForeground(compileErrorAttr, Color.RED); 
            StyleConstants.setBold(compileErrorAttr, true);
            StyleConstants.setUnderline(compileErrorAttr, true);
            
            doc.setCharacterAttributes(start, end - start, compileErrorAttr, false);
            editor.setCaretPosition(start);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void cargarEjemplo() {
        String ejemplo = "cybermain start_netrun\n" +
                        "    const neural MAX_INTENTOS = 3;\n" +
                        "    const floatwave PI = 3.14159;\n" +
                        "    neural intentos = 0;\n" +
                        "    neural numero = 42;\n" +
                        "    floatwave radio = 5.0;\n" +
                        "    logic encontrado = punk;\n" +
                        "    floatwave area = PI;\n" +
                        "    \n" +
                        "    while_sync (intentos < MAX_INTENTOS && !encontrado) start_netrun\n" +
                        "        neural intento = 0;\n" +
                        "        neural calculo = intento + numero;\n" +
                        "        neural complejo = (intento + 10) * 2 - 5;\n" +
                        "        \n" +
                        "        logic esValido = intento > 0 && intento < 100;\n" +
                        "        logic rangoPermitido = (intento >= 20 && intento <= 50) || intento == 42;\n" +
                        "        \n" +
                        "        if_net (intento == numero) start_netrun\n" +
                        "            encontrado = samurai;\n" +
                        "            hack_print(\"Número encontrado\");\n" +
                        "        end_netrun net_else start_netrun\n" +
                        "            intentos++;\n" +
                        "            hack_print(\"Intento fallido\");\n" +
                        "        end_netrun\n" +
                        "    end_netrun\n" +
                        "end_netrun";
        createNewTab("Ejemplo.cpk", ejemplo, null);
    }

    // ══════════════════════════════════════════════════════════
    // CÓDIGO GENERADO DE NETBEANS (NO MODIFICAR)
    // ══════════════════════════════════════════════════════════
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jToolBar1 = new javax.swing.JToolBar();
        btnNuevo = new javax.swing.JButton();
        btnAbrir = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnGuardarTodo = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JToolBar.Separator();
        btnCortar = new javax.swing.JButton();
        btnCopiar = new javax.swing.JButton();
        btnPegar = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        btnCompilar = new javax.swing.JButton();
        btnCorrer = new javax.swing.JButton();
        jSplitPane1 = new javax.swing.JSplitPane();
        jSplitPane2 = new javax.swing.JSplitPane();
        editorTabs = new javax.swing.JTabbedPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        codigoArea = new javax.swing.JTextArea();
        resultScroll = new javax.swing.JScrollPane();
        resultArea = new javax.swing.JTextArea();
        jSplitPane3 = new javax.swing.JSplitPane();
        tokenScroll = new javax.swing.JScrollPane();
        tokenTable = new javax.swing.JTable();
        symbolScroll = new javax.swing.JScrollPane();
        symbolTable = new javax.swing.JTable();
        statusPanel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuArchivo = new javax.swing.JMenu();
        miNuevo = new javax.swing.JMenuItem();
        miAbrir = new javax.swing.JMenuItem();
        miGuardar = new javax.swing.JMenuItem();
        miGuardarComo = new javax.swing.JMenuItem();
        miGuardarTodo = new javax.swing.JMenuItem();
        miCerrar = new javax.swing.JMenuItem();
        miCerrarTodo = new javax.swing.JMenuItem();
        miSalir = new javax.swing.JMenuItem();
        menuEdicion = new javax.swing.JMenu();
        miCopiar = new javax.swing.JMenuItem();
        miCortar = new javax.swing.JMenuItem();
        miPegar = new javax.swing.JMenuItem();
        menuCompilar = new javax.swing.JMenu();
        miCompilar = new javax.swing.JMenuItem();
        miCompilarRun = new javax.swing.JMenuItem();
        miEjemplo = new javax.swing.JMenuItem();
        menuHerramientas = new javax.swing.JMenu();
        miOpciones = new javax.swing.JMenuItem();
        miGramatica = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");
        jMenu3.setText("File");
        jMenuBar2.add(jMenu3);
        jMenu4.setText("Edit");
        jMenuBar2.add(jMenu4);
        jMenuItem2.setText("jMenuItem2");
        jMenuItem3.setText("jMenuItem3");
        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Mi_Compilador");
        setAutoRequestFocus(false);
        setSize(new java.awt.Dimension(1100, 700));

        jToolBar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jToolBar1.setRollover(true);

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/new.png"))); 
        btnNuevo.setFocusable(false);
        btnNuevo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnNuevo.setPreferredSize(new java.awt.Dimension(32, 32));
        btnNuevo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        jToolBar1.add(btnNuevo);

        btnAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/open.png"))); 
        btnAbrir.setFocusable(false);
        btnAbrir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAbrir.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirActionPerformed(evt);
            }
        });
        jToolBar1.add(btnAbrir);

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/save.png"))); 
        btnGuardar.setFocusable(false);
        btnGuardar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGuardar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        jToolBar1.add(btnGuardar);

        btnGuardarTodo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/salvado.png"))); 
        btnGuardarTodo.setFocusable(false);
        btnGuardarTodo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGuardarTodo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGuardarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarTodoActionPerformed(evt);
            }
        });
        jToolBar1.add(btnGuardarTodo);
        jToolBar1.add(jSeparator1);

        btnCortar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/cut.png"))); 
        btnCortar.setFocusable(false);
        btnCortar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCortar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCortar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCortarActionPerformed(evt);
            }
        });
        jToolBar1.add(btnCortar);

        btnCopiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/copy.png"))); 
        btnCopiar.setFocusable(false);
        btnCopiar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCopiar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCopiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCopiarActionPerformed(evt);
            }
        });
        jToolBar1.add(btnCopiar);

        btnPegar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/paste.png"))); 
        btnPegar.setFocusable(false);
        btnPegar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnPegar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnPegar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPegarActionPerformed(evt);
            }
        });
        jToolBar1.add(btnPegar);
        jToolBar1.add(jSeparator2);

        btnCompilar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/compile.png"))); 
        btnCompilar.setFocusable(false);
        btnCompilar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCompilar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCompilar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCompilarActionPerformed(evt);
            }
        });
        jToolBar1.add(btnCompilar);

        btnCorrer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/run.png"))); 
        btnCorrer.setFocusable(false);
        btnCorrer.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCorrer.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCorrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCorrerActionPerformed(evt);
            }
        });
        jToolBar1.add(btnCorrer);

        jSplitPane1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jSplitPane1.setDividerLocation(700);
        jSplitPane1.setResizeWeight(0.7);

        jSplitPane2.setDividerLocation(260);
        jSplitPane2.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);

        editorTabs.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);

        codigoArea.setColumns(20);
        codigoArea.setRows(5);
        jScrollPane1.setViewportView(codigoArea);

        editorTabs.addTab("tab1", jScrollPane1);

        jSplitPane2.setTopComponent(editorTabs);

        resultArea.setEditable(false);
        resultArea.setColumns(20);
        resultArea.setLineWrap(true);
        resultArea.setRows(5);
        resultArea.setWrapStyleWord(true);
        resultScroll.setViewportView(resultArea);

        jSplitPane2.setRightComponent(resultScroll);
        jSplitPane1.setLeftComponent(jSplitPane2);

        jSplitPane3.setDividerLocation(250);
        jSplitPane3.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);

        tokenTable.setAutoCreateRowSorter(true);
        tokenTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Tipo de token", "Lexema", "Posición"
            }
        ));
        tokenScroll.setViewportView(tokenTable);

        jSplitPane3.setTopComponent(tokenScroll);

        symbolTable.setAutoCreateRowSorter(true);
        symbolTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Identificador", "Tipo", "Valor", "Var/Const"
            }
        ) {
            // Hacer la tabla de solo lectura
            @Override public boolean isCellEditable(int row, int col) { return false; }
        });
        symbolScroll.setViewportView(symbolTable);

        jSplitPane3.setRightComponent(symbolScroll);
        jSplitPane1.setRightComponent(jSplitPane3);

        statusPanel.setLayout(new java.awt.BorderLayout());

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 451, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 463, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        statusPanel.add(jPanel1, java.awt.BorderLayout.CENTER);

        menuArchivo.setText("Archivo");

        miNuevo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        miNuevo.setText("Nuevo");
        miNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        menuArchivo.add(miNuevo);

        miAbrir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        miAbrir.setText("Abrir");
        miAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirActionPerformed(evt);
            }
        });
        menuArchivo.add(miAbrir);

        miGuardar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_G, java.awt.event.InputEvent.CTRL_MASK));
        miGuardar.setText("Guardar");
        miGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        menuArchivo.add(miGuardar);

        miGuardarComo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_K, java.awt.event.InputEvent.CTRL_MASK));
        miGuardarComo.setText("Guardar como...");
        miGuardarComo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        menuArchivo.add(miGuardarComo);

        miGuardarTodo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        miGuardarTodo.setText("Guardar Todo");
        miGuardarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarTodoActionPerformed(evt);
            }
        });
        menuArchivo.add(miGuardarTodo);

        miCerrar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.ALT_MASK));
        miCerrar.setText("Cerrar");
        miCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miCerrarActionPerformed(evt);
            }
        });
        menuArchivo.add(miCerrar);

        miCerrarTodo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.ALT_MASK));
        miCerrarTodo.setText("Cerrar todo...");
        miCerrarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miCerrarTodoActionPerformed(evt);
            }
        });
        menuArchivo.add(miCerrarTodo);

        miSalir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.ALT_MASK));
        miSalir.setText("Salir");
        miSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miSalirActionPerformed(evt);
            }
        });
        menuArchivo.add(miSalir);

        jMenuBar1.add(menuArchivo);

        menuEdicion.setText("Edicion");

        miCopiar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        miCopiar.setText("Copiar");
        miCopiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCopiarActionPerformed(evt);
            }
        });
        menuEdicion.add(miCopiar);

        miCortar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
        miCortar.setText("Cortar");
        miCortar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCortarActionPerformed(evt);
            }
        });
        menuEdicion.add(miCortar);

        miPegar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.CTRL_MASK));
        miPegar.setText("Pegar");
        miPegar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPegarActionPerformed(evt);
            }
        });
        menuEdicion.add(miPegar);

        jMenuBar1.add(menuEdicion);

        menuCompilar.setText("Compilar");

        miCompilar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F11, 0));
        miCompilar.setText("Compilar");
        miCompilar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCompilarActionPerformed(evt);
            }
        });
        menuCompilar.add(miCompilar);

        miCompilarRun.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F6, 0));
        miCompilarRun.setText("Compilar y correr");
        miCompilarRun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCorrerActionPerformed(evt);
            }
        });
        menuCompilar.add(miCompilarRun);

        miEjemplo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F12, 0));
        miEjemplo.setText("Mi ejemplo");
        miEjemplo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cargarEjemplo();
            }
        });
        menuCompilar.add(miEjemplo);

        jMenuBar1.add(menuCompilar);

        menuHerramientas.setText("Herramientas");

        miOpciones.setText("Opciones...");
        miOpciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miOpcionesActionPerformed(evt);
            }
        });
        menuHerramientas.add(miOpciones);

        miGramatica.setText("Ver gramatica");
        miGramatica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miGramaticaActionPerformed(evt);
            }
        });
        menuHerramientas.add(miGramatica);

        jMenuBar1.add(menuHerramientas);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSplitPane1)
                    .addComponent(statusPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSplitPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 517, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(statusPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        tokenTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        symbolTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        pack();
    }// </editor-fold>                        

    // ══════════════════════════════════════════════════════════
    // EVENTOS DE BOTONES
    // ══════════════════════════════════════════════════════════
    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {                                         
        JTextPane editorActual = getCurrentEditor();
        if (editorActual != null) {
            Boolean modificado = archivosModificados.get(editorActual);
            if (modificado != null && modificado) {
                int respuesta = JOptionPane.showConfirmDialog(this, 
                    "Tiene cambios sin guardar en la pestaña actual.\n¿Desea guardar antes de crear nuevo?", 
                    "Confirmar nuevo", 
                    JOptionPane.YES_NO_CANCEL_OPTION);
                
                if (respuesta == JOptionPane.YES_OPTION) {
                    guardarArchivo(editorActual);
                } else if (respuesta == JOptionPane.CANCEL_OPTION) {
                    return;
                }
            }
        }
        createNewTab("Nuevo.cpk", "", null);
    }                                        

    private void btnAbrirActionPerformed(java.awt.event.ActionEvent evt) {                                         
        abrirArchivo();
    }                                        

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {                                           
        JTextPane editor = getCurrentEditor();
        if (editor != null) {
            guardarArchivo(editor);
        }
    }                                          

    private void btnGuardarTodoActionPerformed(java.awt.event.ActionEvent evt) {                                               
        for (int i = 0; i < editorTabs.getTabCount(); i++) {
            JTextPane editor = getEditorFromComponent(editorTabs.getComponentAt(i));
            if (editor != null) {
                Boolean modificado = archivosModificados.get(editor);
                if (modificado != null && modificado) {
                    File archivo = archivosAbiertos.get(editor);
                    if (archivo == null) {
                        String nombreTab = editorTabs.getTitleAt(i).replace("*", "");
                        int respuesta = JOptionPane.showConfirmDialog(this, 
                            "¿Desea guardar el archivo: " + nombreTab + "?", 
                            "Guardar archivo", 
                            JOptionPane.YES_NO_CANCEL_OPTION);
                        
                        if (respuesta == JOptionPane.YES_OPTION) {
                            guardarArchivo(editor); 
                        }
                    } else {
                        guardarArchivo(editor);
                    }
                }
            }
        }
    }                                              

    private void btnCortarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        JTextPane editor = getCurrentEditor();
        if (editor != null) {
            editor.cut();
        }
    }                                         

    private void btnCopiarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        JTextPane editor = getCurrentEditor(); 
        if (editor != null) {
            editor.copy();
        }
    }                                         

    private void btnPegarActionPerformed(java.awt.event.ActionEvent evt) {                                         
        JTextPane editor = getCurrentEditor();
        if (editor != null) {
            editor.paste();
        }
    }                                        

    private void btnCompilarActionPerformed(java.awt.event.ActionEvent evt) {                                            
        compilarCodigo();
    }                                           

    private void btnCorrerActionPerformed(java.awt.event.ActionEvent evt) {                                          
        compilarCodigo();
        resultArea.append("\n=== SIMULACIÓN DE EJECUCIÓN ===\n");
        resultArea.append("Ejecutando programa...\n");
        
        JTextPane editor = getCurrentEditor();
        if (editor != null) {
            String codigo = editor.getText();
            if (codigo.contains("hack_print")) {
                resultArea.append("Salida del programa:\n");
                resultArea.append("-------------------\n");
                java.util.regex.Pattern p = java.util.regex.Pattern.compile("hack_print\\(\"([^\"]*)\"\\)");
                java.util.regex.Matcher m = p.matcher(codigo);
                while (m.find()) {
                    resultArea.append(m.group(1) + "\n");
                }
            }
        }
    }                                         

    private void miCerrarActionPerformed(java.awt.event.ActionEvent evt) {                                         
        int selectedIndex = editorTabs.getSelectedIndex();
        if (selectedIndex >= 0) {
            JTextPane editor = getCurrentEditor();
            if (editor != null) {
                Boolean modificado = archivosModificados.get(editor);
                if (modificado != null && modificado) {
                    String nombreTab = editorTabs.getTitleAt(selectedIndex).replace("*", "");
                    int respuesta = JOptionPane.showConfirmDialog(this, 
                        "El archivo '" + nombreTab + "' tiene cambios sin guardar.\n¿Desea guardarlo antes de cerrar?", 
                        "Confirmar cierre", 
                        JOptionPane.YES_NO_CANCEL_OPTION);
                    
                    if (respuesta == JOptionPane.YES_OPTION) {
                        boolean guardado = guardarArchivo(editor);
                        if (!guardado) return; 
                    } else if (respuesta == JOptionPane.CANCEL_OPTION) {
                        return; 
                    }
                }
                archivosAbiertos.remove(editor);
                archivosModificados.remove(editor);
            }
            editorTabs.removeTabAt(selectedIndex);
        }
    }                                        

    private void miCerrarTodoActionPerformed(java.awt.event.ActionEvent evt) {                                             
        editorTabs.removeAll();
    }                                            

    private void miSalirActionPerformed(java.awt.event.ActionEvent evt) {                                        
        if (verificarArchivosSinGuardar()) {
            System.exit(0);
        }
    }                                       

    private void miGramaticaActionPerformed(java.awt.event.ActionEvent evt) {                                            
        String gramatica = "=== GRAMÁTICA CYBERPUNK ===\n\n" +
                      "PROGRAM → cybermain start_netrun STATEMENTS end_netrun\n" +
                      "STATEMENTS → STATEMENT | STATEMENT STATEMENTS\n" +
                      "STATEMENT → DECLARATION | ASSIGNMENT | IF | FOR | WHILE | PRINT | SCAN\n" +
                      "DECLARATION → TYPE IDENTIFIER [ = EXPRESSION ] ;\n" +
                      "TYPE → neural | floatwave | datastring | logic | charbyte | synthbyte\n" +
                      "ASSIGNMENT → IDENTIFIER = EXPRESSION ;\n" +
                      "EXPRESSION → TERM | EXPRESSION OP_ARITH TERM\n" +
                      "TERM → IDENTIFIER | NUMBER | STRING | ( EXPRESSION )\n" +
                      "OP_ARITH → + | - | * | / | %\n" +
                      "OP_REL → > | < | >= | <= | == | !=\n" +
                      "OP_LOG → && | || | !\n" +
                      "IF → if_net ( EXPRESSION ) start_netrun STATEMENTS end_netrun [ net_else start_netrun STATEMENTS end_netrun ]\n" +
                      "FOR → for_loop ( DECLARATION ; EXPRESSION ; INCREMENT ) start_netrun STATEMENTS end_netrun\n" +
                      "WHILE → while_sync ( EXPRESSION ) start_netrun STATEMENTS end_netrun\n" +
                      "PRINT → hack_print ( EXPRESSION ) ;\n" +
                      "SCAN → neural_scan ( IDENTIFIER ) ;\n\n" +
                      "=== PALABRAS RESERVADAS ===\n" +
                      "cybermain, start_netrun, end_netrun, neural, floatwave,\n" +
                      "datastring, charbyte, logic, synthbyte, if_net, net_else,\n" +
                      "switch_grid, for_loop, do_netrun, while_sync, repeat_until,\n" +
                      "hack_print, neural_scan, samurai, punk, night, edgerunner";
        
        JTextArea textArea = new JTextArea(gramatica);
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(600, 400));
        
        JOptionPane.showMessageDialog(this, scrollPane, "Gramática del Lenguaje", JOptionPane.INFORMATION_MESSAGE);
    }                                           

    private void miOpcionesActionPerformed(java.awt.event.ActionEvent evt) {                                           
        javax.swing.JCheckBox mostrarLineas = new javax.swing.JCheckBox("Mostrar números de línea");
        javax.swing.JCheckBox autoGuardar = new javax.swing.JCheckBox("Auto-guardar cada 5 minutos");
        Object[] message = { "Configuración del editor:", mostrarLineas, autoGuardar };
        
        int option = JOptionPane.showConfirmDialog(this, message, "Opciones", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            JOptionPane.showMessageDialog(this, "Opciones guardadas");
        }
    }                                          

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {}

        SplashScreen splash = new SplashScreen(2000); 
        splash.showSplash(); 
    }

    private void updateMenuStates() {
        boolean hasTabs = editorTabs.getTabCount() > 0;
        boolean isEditorSelected = editorTabs.getSelectedIndex() >= 0;
        
        miGuardar.setEnabled(isEditorSelected);
        miGuardarComo.setEnabled(isEditorSelected);
        miCerrar.setEnabled(isEditorSelected);
        miGuardarTodo.setEnabled(hasTabs);
        miCerrarTodo.setEnabled(hasTabs);
        miCopiar.setEnabled(isEditorSelected);
        miCortar.setEnabled(isEditorSelected);
        miPegar.setEnabled(isEditorSelected);
        
        btnGuardar.setEnabled(isEditorSelected);
        btnGuardarTodo.setEnabled(hasTabs);
        btnCopiar.setEnabled(isEditorSelected);
        btnCortar.setEnabled(isEditorSelected);
        btnPegar.setEnabled(isEditorSelected);
        btnCompilar.setEnabled(isEditorSelected);
        btnCorrer.setEnabled(isEditorSelected);
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton btnAbrir;
    private javax.swing.JButton btnCompilar;
    private javax.swing.JButton btnCopiar;
    private javax.swing.JButton btnCorrer;
    private javax.swing.JButton btnCortar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnGuardarTodo;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnPegar;
    private javax.swing.JTextArea codigoArea;
    private javax.swing.JTabbedPane editorTabs;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToolBar.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JSplitPane jSplitPane2;
    private javax.swing.JSplitPane jSplitPane3;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JMenu menuArchivo;
    private javax.swing.JMenu menuCompilar;
    private javax.swing.JMenu menuEdicion;
    private javax.swing.JMenu menuHerramientas;
    private javax.swing.JMenuItem miAbrir;
    private javax.swing.JMenuItem miCerrar;
    private javax.swing.JMenuItem miCerrarTodo;
    private javax.swing.JMenuItem miCompilar;
    private javax.swing.JMenuItem miCompilarRun;
    private javax.swing.JMenuItem miCopiar;
    private javax.swing.JMenuItem miCortar;
    private javax.swing.JMenuItem miEjemplo;
    private javax.swing.JMenuItem miGramatica;
    private javax.swing.JMenuItem miGuardar;
    private javax.swing.JMenuItem miGuardarComo;
    private javax.swing.JMenuItem miGuardarTodo;
    private javax.swing.JMenuItem miNuevo;
    private javax.swing.JMenuItem miOpciones;
    private javax.swing.JMenuItem miPegar;
    private javax.swing.JMenuItem miSalir;
    private javax.swing.JTextArea resultArea;
    private javax.swing.JScrollPane resultScroll;
    private javax.swing.JPanel statusPanel;
    private javax.swing.JScrollPane symbolScroll;
    private javax.swing.JTable symbolTable;
    private javax.swing.JScrollPane tokenScroll;
    private javax.swing.JTable tokenTable;
    // End of variables declaration                   
}
