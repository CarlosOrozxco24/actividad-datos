package compilador;

import compilerTools.ErrorLSSL;
import compilerTools.Grammar;
import compilerTools.Token;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Analizador Sintáctico Mejorado para el Compilador Cyberpunk
 * Incluye soporte para:
 * - Expresiones relacionales simples y complejas
 * - Expresiones aritméticas simples y complejas (incluyendo ++/--)
 * - Tabla de símbolos mejorada
 * - Manejo robusto de errores con descripciones detalladas
 */
public class AnalizadorSintacticoMejorado {
    
    private ArrayList<Token> tokens;
    private ArrayList<ErrorLSSL> errors;
    private HashMap<String, Symbol> symbolsMap;
    private Grammar gramatica;
    
    public AnalizadorSintacticoMejorado(ArrayList<Token> tokens, 
                                        ArrayList<ErrorLSSL> errors,
                                        HashMap<String, Symbol> symbolsMap) {
        this.tokens = tokens;
        this.errors = errors;
        this.symbolsMap = symbolsMap;
        this.gramatica = new Grammar(tokens, errors);
    }
    
    /**
     * Método principal que ejecuta el análisis sintáctico completo
     */
    public void analizar() {
        // Paso 1: Eliminar errores léxicos conocidos
        eliminarErroresLexicos();
        
        // Paso 2: Definir agrupaciones básicas
        definirAgrupacionesBasicas();
        
        // Paso 3: Definir expresiones (aritméticas y relacionales)
        definirExpresiones();
        
        // Paso 4: Definir estructuras de control
        definirEstructurasControl();
        
        // Paso 5: Definir declaraciones (incluyendo múltiples)
        definirDeclaraciones();
        
        // Paso 6: Definir programa principal
        definirProgramaPrincipal();
        
        // Paso 7: Ejecutar análisis
        gramatica.show();
        
        // Paso 8: Poblar tabla de símbolos
        poblarTablaSimbolos();
        
        // Paso 9: Validar uso de símbolos
        validarUsoSimbolos();
        
        // Paso 10: Definir errores sintácticos
        definirErroresSintacticos();
    }
    
    /**
     * Elimina tokens de error léxico del análisis
     */
    private void eliminarErroresLexicos() {
        gramatica.delete(new String[]{
            "ERROR_LEXICO_GENERAL", 
            "ERROR_CARACTER_INVALIDO", 
            "ERROR_ENTERO_CERO", 
            "ERROR_FLOTANTE_CERO", 
            "ERROR_IDENTIFICADOR",
            "ERROR_IDENTIFICADOR_NUMERICO"
        }, 1);
    }
    
    /**
     * Define las agrupaciones sintácticas básicas
     */
    private void definirAgrupacionesBasicas() {
        // Valores literales
        gramatica.group("VALOR", 
            "(ENTERO | FLOTANTE | CADENA | CARACTER | " +
            "CONST_SAMURAI | CONST_PUNK | CONST_NIGHT | " +
            "CONST_EDGERUNNER | CONST_LUCY | CONST_DAVID)", true);
        
        // Tipos de datos
        gramatica.group("TIPO_DATO", 
            "(INT | FLOAT | STRING_TYPE | CHAR_TYPE | BOOL_TYPE | BYTE_TYPE)", true);
        
        // Operadores aritméticos
        gramatica.group("OP_ARITMETICO", 
            "(SUMA | RESTA | MULTIPLICACION | DIVISION | MODULO)", true);
        
        // Operadores relacionales
        gramatica.group("OP_RELACIONAL", 
            "(MAYOR | MENOR | MAYOR_IGUAL | MENOR_IGUAL | IGUAL_IGUAL | DIFERENTE)", true);
        
        // Operadores lógicos
        gramatica.group("OP_LOGICO", 
            "(AND | OR)", true);
        
        // Operadores unarios
        gramatica.group("OP_UNARIO", 
            "(NOT | RESTA | SUMA)", true);
        
        // Operadores de incremento/decremento
        gramatica.group("OP_INCREMENTO", 
            "(INCREMENTO | DECREMENTO)", true);
    }
    
    /**
     * Define las expresiones aritméticas y relacionales
     * Implementa precedencia de operadores correcta
     */
    private void definirExpresiones() {
        gramatica.loopForFunExecUntilChangeNotDetected(() -> {
            // === EXPRESIONES ARITMÉTICAS ===
            
            // Nivel 0: Primarias (valores base y operaciones unarias)
            // Soporta: x++, ++x, x--, --x, -x, +x, !x
            gramatica.group("PRIMARIA", 
                "OP_INCREMENTO? (IDENTIFICADOR | VALOR | " +
                "PARENTESIS_ABRE EXPRESION PARENTESIS_CIERRA) OP_INCREMENTO?");
            
            gramatica.group("PRIMARIA", 
                "OP_UNARIO (IDENTIFICADOR | VALOR | " +
                "PARENTESIS_ABRE EXPRESION PARENTESIS_CIERRA)");
            
            // Nivel 1: Factor (multiplicación, división, módulo)
            gramatica.group("FACTOR", 
                "PRIMARIA ((MULTIPLICACION | DIVISION | MODULO) PRIMARIA)*");
            
            // Nivel 2: Término (suma y resta)
            gramatica.group("TERMINO", 
                "FACTOR ((SUMA | RESTA) FACTOR)*");
            
            // === EXPRESIONES RELACIONALES ===
            
            // Nivel 3: Comparación (operadores relacionales)
            // a) Expresiones relacionales SIMPLES: x > 5, y == 10
            gramatica.group("COMPARACION_SIMPLE", 
                "TERMINO OP_RELACIONAL TERMINO");
            
            // b) Expresiones relacionales COMPLEJAS: múltiples comparaciones
            gramatica.group("COMPARACION", 
                "TERMINO (OP_RELACIONAL TERMINO)*");
            
            // === EXPRESIONES LÓGICAS ===
            
            // Nivel 4: AND lógico
            // b) Expresiones lógicas COMPLEJAS: x > 5 && y < 10 && z == 3
            gramatica.group("LOGICO_AND", 
                "COMPARACION (AND COMPARACION)*");
            
            // Nivel 5: OR lógico
            // b) Más expresiones lógicas COMPLEJAS: (x && y) || (z && w)
            gramatica.group("LOGICO_OR", 
                "LOGICO_AND (OR LOGICO_AND)*");
            
            // Expresión final (cualquier expresión válida)
            gramatica.group("EXPRESION", "LOGICO_OR");
            
            // Alternativa: una expresión puede ser solo un término aritmético
            gramatica.group("EXPRESION", "TERMINO");
        });
    }
    
    /**
     * Define las declaraciones de variables (simples y múltiples)
     */
    private void definirDeclaraciones() {
        gramatica.loopForFunExecUntilChangeNotDetected(() -> {
            // === DECLARACIONES MÚLTIPLES ===
            // Soporte para: neural x, y, z;
            // Soporte para: neural x = 5, y = 10, z;
            
            // Declaración de una variable con inicialización opcional
            gramatica.group("DECL_VAR_SIMPLE", 
                "IDENTIFICADOR (ASIGNACION EXPRESION)?");
            
            // Lista de variables (separadas por comas)
            gramatica.group("LISTA_VARIABLES", 
                "DECL_VAR_SIMPLE (COMA DECL_VAR_SIMPLE)*");
            
            // Declaración múltiple completa
            gramatica.group("DECLARACION_MULTIPLE", 
                "TIPO_DATO LISTA_VARIABLES PUNTO_COMA");
            
            // Declaración con const
            gramatica.group("DECLARACION_CONSTANTE", 
                "CONST TIPO_DATO IDENTIFICADOR ASIGNACION EXPRESION PUNTO_COMA");
            
            // === ASIGNACIONES ===
            
            // Asignación simple: x = 5;
            gramatica.group("ASIGNACION", 
                "IDENTIFICADOR ASIGNACION EXPRESION PUNTO_COMA");
            
            // Asignaciones compuestas: x += 5, x -= 3, etc.
            gramatica.group("ASIGNACION_COMPUESTA", 
                "IDENTIFICADOR (SUMA_ASIGNACION | RESTA_ASIGNACION | " +
                "MULTIPLICACION_ASIGNACION | DIVISION_ASIGNACION | " +
                "MODULO_ASIGNACION) EXPRESION PUNTO_COMA");
            
            // Sentencia de incremento/decremento: x++; ++x; x--; --x;
            gramatica.group("SENTENCIA_INCREMENTO", 
                "(OP_INCREMENTO IDENTIFICADOR | IDENTIFICADOR OP_INCREMENTO) PUNTO_COMA");
            
            // Error: falta punto y coma en asignación
            gramatica.group("ASIGNACION", 
                "IDENTIFICADOR ASIGNACION EXPRESION", 
                true, 101, "Error Sintáctico: Se esperaba ; al final de la asignación [#]");
        });
    }
    
    /**
     * Define las estructuras de control (if, while, for, etc.)
     */
    private void definirEstructurasControl() {
        gramatica.loopForFunExecUntilChangeNotDetected(() -> {
            // Bloque de código
            gramatica.group("BLOQUE", 
                "START_BLOCK SENTENCIAS* END_BLOCK");
            
            // === ESTRUCTURA IF ===
            gramatica.group("ESTRUCTURA_IF", 
                "IF PARENTESIS_ABRE EXPRESION PARENTESIS_CIERRA BLOQUE (ELSE BLOQUE)?");
            
            // Error: falta expresión en if
            gramatica.group("ESTRUCTURA_IF", 
                "IF PARENTESIS_ABRE PARENTESIS_CIERRA BLOQUE", 
                true, 102, "Error Sintáctico: Se esperaba una expresión válida en la condición del if [#]");
            
            // === ESTRUCTURA WHILE ===
            gramatica.group("ESTRUCTURA_WHILE", 
                "WHILE PARENTESIS_ABRE EXPRESION PARENTESIS_CIERRA BLOQUE");
            
            // Error: falta expresión en while
            gramatica.group("ESTRUCTURA_WHILE", 
                "WHILE PARENTESIS_ABRE PARENTESIS_CIERRA BLOQUE", 
                true, 103, "Error Sintáctico: Se esperaba una expresión válida en la condición del while [#]");
            
            // === ESTRUCTURA FOR ===
            // for_loop (inicialización; condición; incremento) { }
            gramatica.group("FOR_INIT", 
                "(DECLARACION_MULTIPLE | ASIGNACION | SENTENCIA_INCREMENTO)");
            
            gramatica.group("FOR_PARAMETROS", 
                "PARENTESIS_ABRE FOR_INIT EXPRESION PUNTO_COMA " +
                "(ASIGNACION | SENTENCIA_INCREMENTO | EXPRESION) PARENTESIS_CIERRA");
            
            gramatica.group("ESTRUCTURA_FOR", 
                "FOR FOR_PARAMETROS BLOQUE");
            
            // === FUNCIONES DE E/S ===
            gramatica.group("FUNCION_PRINT", 
                "PRINT PARENTESIS_ABRE EXPRESION PARENTESIS_CIERRA PUNTO_COMA");
            
            gramatica.group("FUNCION_SCAN", 
                "SCAN PARENTESIS_ABRE IDENTIFICADOR PARENTESIS_CIERRA PUNTO_COMA");
            
            // Error: falta punto y coma en print
            gramatica.group("FUNCION_PRINT", 
                "PRINT PARENTESIS_ABRE EXPRESION PARENTESIS_CIERRA", 
                true, 104, "Error Sintáctico: Se esperaba ; después de la función hack_print [#]");
        });
    }
    
    /**
     * Define el programa principal y las sentencias válidas
     */
    private void definirProgramaPrincipal() {
        gramatica.loopForFunExecUntilChangeNotDetected(() -> {
            // Sentencias válidas
            gramatica.group("SENTENCIAS", 
                "(DECLARACION_MULTIPLE | DECLARACION_CONSTANTE | ASIGNACION | " +
                "ASIGNACION_COMPUESTA | SENTENCIA_INCREMENTO | " +
                "ESTRUCTURA_IF | ESTRUCTURA_WHILE | ESTRUCTURA_FOR | " +
                "FUNCION_PRINT | FUNCION_SCAN)");
            
            // Programa principal
            gramatica.group("METODO_MAIN", 
                "MAIN BLOQUE", true);
        });
    }
    
    /**
     * Puebla la tabla de símbolos analizando las declaraciones
     */
    private void poblarTablaSimbolos() {
        for (int i = 0; i < tokens.size(); i++) {
            Token t = tokens.get(i);
            String tipoLex = t.getLexicalComp();
            
            // Detectar declaraciones de variables
            if (esTipoDato(tipoLex)) {
                procesarDeclaracion(i);
            }
            
            // Detectar constantes
            if (tipoLex.equals("CONST") && i + 1 < tokens.size()) {
                procesarConstante(i);
            }
        }
    }
    
    /**
     * Verifica si un token es un tipo de dato
     */
    private boolean esTipoDato(String tipo) {
        return tipo.equals("INT") || tipo.equals("FLOAT") || 
               tipo.equals("STRING_TYPE") || tipo.equals("CHAR_TYPE") || 
               tipo.equals("BOOL_TYPE") || tipo.equals("BYTE_TYPE");
    }
    
    /**
     * Procesa una declaración de variable(s)
     * Soporta declaraciones múltiples: neural x, y, z;
     */
    private void procesarDeclaracion(int posicion) {
        if (posicion + 1 >= tokens.size()) return;
        
        Token tipoDato = tokens.get(posicion);
        String tipo = tipoDato.getLexicalComp();
        
        // Procesar todas las variables declaradas en esta línea
        int i = posicion + 1;
        while (i < tokens.size()) {
            Token token = tokens.get(i);
            
            // Si encontramos punto y coma, terminamos
            if (token.getLexicalComp().equals("PUNTO_COMA")) {
                break;
            }
            
            // Si es un identificador, es una variable
            if (token.getLexicalComp().equals("IDENTIFICADOR")) {
                String id = token.getLexeme();
                Object valor = null;
                
                // Verificar si tiene inicialización
                if (i + 2 < tokens.size() && 
                    tokens.get(i + 1).getLexicalComp().equals("ASIGNACION")) {
                    // Tiene valor inicial
                    Token valorToken = tokens.get(i + 2);
                    valor = obtenerValorToken(valorToken);
                    i += 2; // Saltar = y valor
                }
                
                // Verificar si ya existe
                if (symbolsMap.containsKey(id)) {
                    errors.add(new ErrorLSSL(2, 
                        "Error Semántico: Variable '" + id + "' ya fue declarada [línea " + 
                        token.getLine() + "]", token));
                } else {
                    // Agregar a la tabla de símbolos
                    Symbol sym = new Symbol(id, tipo, valor, false, 
                                          token.getLine(), token.getColumn(), "global");
                    symbolsMap.put(id, sym);
                }
            }
            i++;
        }
    }
    
    /**
     * Procesa una declaración de constante
     */
    private void procesarConstante(int posicion) {
        if (posicion + 3 >= tokens.size()) return;
        
        Token tipoDato = tokens.get(posicion + 1);
        Token identificador = tokens.get(posicion + 2);
        
        if (!identificador.getLexicalComp().equals("IDENTIFICADOR")) return;
        
        String tipo = tipoDato.getLexicalComp();
        String id = identificador.getLexeme();
        Object valor = null;
        
        // Las constantes DEBEN tener valor inicial
        if (posicion + 4 < tokens.size() && 
            tokens.get(posicion + 3).getLexicalComp().equals("ASIGNACION")) {
            Token valorToken = tokens.get(posicion + 4);
            valor = obtenerValorToken(valorToken);
        } else {
            errors.add(new ErrorLSSL(2, 
                "Error Semántico: La constante '" + id + "' debe ser inicializada [línea " + 
                identificador.getLine() + "]", identificador));
            return;
        }
        
        if (symbolsMap.containsKey(id)) {
            errors.add(new ErrorLSSL(2, 
                "Error Semántico: El símbolo '" + id + "' ya fue declarado [línea " + 
                identificador.getLine() + "]", identificador));
        } else {
            Symbol sym = new Symbol(id, tipo, valor, true, 
                                  identificador.getLine(), identificador.getColumn(), "global");
            symbolsMap.put(id, sym);
        }
    }
    
    /**
     * Obtiene el valor de un token
     */
    private Object obtenerValorToken(Token token) {
        String tipo = token.getLexicalComp();
        switch (tipo) {
            case "ENTERO":
                return Integer.parseInt(token.getLexeme());
            case "FLOTANTE":
                return Float.parseFloat(token.getLexeme());
            case "CADENA":
                return token.getLexeme().replaceAll("\"", "");
            case "CARACTER":
                return token.getLexeme().charAt(1);
            default:
                return token.getLexeme();
        }
    }
    
    /**
     * Valida el uso de símbolos (variables no declaradas, constantes modificadas, etc.)
     */
    private void validarUsoSimbolos() {
        for (int i = 0; i < tokens.size(); i++) {
            Token t = tokens.get(i);
            
            // Verificar uso de identificadores
            if (t.getLexicalComp().equals("IDENTIFICADOR")) {
                String id = t.getLexeme();
                
                // Verificar si está declarado
                if (!symbolsMap.containsKey(id)) {
                    // Saltar si es una declaración
                    if (i > 0 && esTipoDato(tokens.get(i - 1).getLexicalComp())) {
                        continue;
                    }
                    
                    errors.add(new ErrorLSSL(2, 
                        "Error Semántico: Variable '" + id + "' no ha sido declarada [línea " + 
                        t.getLine() + "]", t));
                }
                // Verificar si se intenta modificar una constante
                else if (i + 1 < tokens.size()) {
                    Token siguiente = tokens.get(i + 1);
                    if (siguiente.getLexicalComp().equals("ASIGNACION") || 
                        siguiente.getLexicalComp().contains("ASIGNACION") ||
                        siguiente.getLexicalComp().equals("INCREMENTO") ||
                        siguiente.getLexicalComp().equals("DECREMENTO")) {
                        
                        Symbol sym = symbolsMap.get(id);
                        if (sym.isConst) {
                            errors.add(new ErrorLSSL(2, 
                                "Error Semántico: No se puede modificar la constante '" + id + 
                                "' [línea " + t.getLine() + "]", t));
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Define todos los mensajes de error sintáctico de forma exhaustiva
     */
    private void definirErroresSintacticos() {
        
        // ═══════════════════════════════════════════════════════
        // GRUPO 1: PUNTO Y COMA FALTANTE
        // ═══════════════════════════════════════════════════════
        
        // Declaración de variable sin ;
        gramatica.group("DECLARACION_MULTIPLE", "TIPO_DATO LISTA_VARIABLES",
            true, 1, "Error Sintáctico {1}: Se esperaba ';' al final de la declaración [#]");
        
        // Asignación simple sin ;
        gramatica.group("ASIGNACION", "IDENTIFICADOR ASIGNACION EXPRESION",
            true, 1, "Error Sintáctico {1}: Se esperaba ';' al final de la asignación [#]");
        
        // Constante sin ;
        gramatica.group("DECLARACION_CONSTANTE", "CONST TIPO_DATO IDENTIFICADOR ASIGNACION EXPRESION",
            true, 1, "Error Sintáctico {1}: Se esperaba ';' al final de la declaración de constante [#]");
        
        // hack_print bien formado sin ;
        gramatica.group("FUNCION_PRINT", "PRINT PARENTESIS_ABRE EXPRESION PARENTESIS_CIERRA",
            true, 1, "Error Sintáctico {1}: Se esperaba ';' después de hack_print(...) [#]");
        
        // neural_scan bien formado sin ;
        gramatica.group("FUNCION_SCAN", "SCAN PARENTESIS_ABRE IDENTIFICADOR PARENTESIS_CIERRA",
            true, 1, "Error Sintáctico {1}: Se esperaba ';' después de neural_scan(...) [#]");
        
        // Incremento/decremento sin ;
        gramatica.group("SENTENCIA_INCREMENTO", "IDENTIFICADOR OP_INCREMENTO",
            true, 1, "Error Sintáctico {1}: Se esperaba ';' después de incremento/decremento [#]");
        
        gramatica.group("SENTENCIA_INCREMENTO", "OP_INCREMENTO IDENTIFICADOR",
            true, 1, "Error Sintáctico {1}: Se esperaba ';' después de incremento/decremento prefijo [#]");
        
        // Asignación compuesta sin ;
        gramatica.group("ASIGNACION_COMPUESTA",
            "IDENTIFICADOR (SUMA_ASIGNACION | RESTA_ASIGNACION | MULTIPLICACION_ASIGNACION | DIVISION_ASIGNACION | MODULO_ASIGNACION) EXPRESION",
            true, 1, "Error Sintáctico {1}: Se esperaba ';' al final de la asignación compuesta [#]");

        // ═══════════════════════════════════════════════════════
        // GRUPO 2: IDENTIFICADOR FALTANTE
        // ═══════════════════════════════════════════════════════
        
        gramatica.group("DECLARACION_MULTIPLE", "TIPO_DATO PUNTO_COMA",
            true, 3, "Error Sintáctico {3}: Se esperaba un identificador válido después del tipo de dato [#]");
        
        gramatica.group("DECLARACION_MULTIPLE", "TIPO_DATO VALOR",
            true, 3, "Error Sintáctico {3}: Se esperaba un identificador, no un literal [#]");
        
        gramatica.group("FUNCION_SCAN", "SCAN PARENTESIS_ABRE PARENTESIS_CIERRA PUNTO_COMA",
            true, 3, "Error Sintáctico {3}: Se esperaba un identificador dentro de neural_scan [#]");
        
        gramatica.group("DECLARACION_CONSTANTE", "CONST TIPO_DATO ASIGNACION EXPRESION PUNTO_COMA",
            true, 3, "Error Sintáctico {3}: Se esperaba un identificador en la declaración de constante [#]");

        // ═══════════════════════════════════════════════════════
        // GRUPO 3: OPERADOR = FALTANTE
        // ═══════════════════════════════════════════════════════
        
        gramatica.group("ASIGNACION", "IDENTIFICADOR EXPRESION PUNTO_COMA",
            true, 32, "Error Sintáctico {32}: Se esperaba el operador '=' en la asignación [#]");
        
        gramatica.group("DECLARACION_CONSTANTE", "CONST TIPO_DATO IDENTIFICADOR PUNTO_COMA",
            true, 32, "Error Sintáctico {32}: La constante debe ser inicializada con '=' [#]");

        // ═══════════════════════════════════════════════════════
        // GRUPO 4: PARÉNTESIS EN if_net
        // ═══════════════════════════════════════════════════════
        
        gramatica.group("ESTRUCTURA_IF", "IF PARENTESIS_ABRE EXPRESION BLOQUE",
            true, 12, "Error Sintáctico {12}: Se esperaba ')' para cerrar la condición de if_net [#]");
        
        gramatica.group("ESTRUCTURA_IF", "IF EXPRESION PARENTESIS_CIERRA BLOQUE",
            true, 13, "Error Sintáctico {13}: Se esperaba '(' para abrir la condición de if_net [#]");
        
        gramatica.group("ESTRUCTURA_IF", "IF EXPRESION BLOQUE",
            true, 13, "Error Sintáctico {13}: Se esperaban '(' y ')' en la condición de if_net [#]");
        
        gramatica.group("ESTRUCTURA_IF", "IF PARENTESIS_ABRE PARENTESIS_CIERRA BLOQUE",
            true, 22, "Error Sintáctico {22}: La condición de if_net está vacía [#]");
        
        gramatica.group("ESTRUCTURA_IF", "IF PARENTESIS_ABRE EXPRESION PARENTESIS_CIERRA SENTENCIAS",
            true, 10, "Error Sintáctico {10}: Se esperaba 'start_netrun' para abrir el bloque de if_net [#]");

        // ═══════════════════════════════════════════════════════
        // GRUPO 5: PARÉNTESIS EN while_sync
        // ═══════════════════════════════════════════════════════
        
        gramatica.group("ESTRUCTURA_WHILE", "WHILE PARENTESIS_ABRE EXPRESION BLOQUE",
            true, 12, "Error Sintáctico {12}: Se esperaba ')' para cerrar la condición de while_sync [#]");
        
        gramatica.group("ESTRUCTURA_WHILE", "WHILE EXPRESION PARENTESIS_CIERRA BLOQUE",
            true, 13, "Error Sintáctico {13}: Se esperaba '(' para abrir la condición de while_sync [#]");
        
        gramatica.group("ESTRUCTURA_WHILE", "WHILE EXPRESION BLOQUE",
            true, 13, "Error Sintáctico {13}: Se esperaban '(' y ')' en la condición de while_sync [#]");
        
        gramatica.group("ESTRUCTURA_WHILE", "WHILE PARENTESIS_ABRE PARENTESIS_CIERRA BLOQUE",
            true, 23, "Error Sintáctico {23}: La condición de while_sync está vacía [#]");
        
        gramatica.group("ESTRUCTURA_WHILE", "WHILE PARENTESIS_ABRE EXPRESION PARENTESIS_CIERRA SENTENCIAS",
            true, 10, "Error Sintáctico {10}: Se esperaba 'start_netrun' para abrir el bloque de while_sync [#]");

        // ═══════════════════════════════════════════════════════
        // GRUPO 6: ERRORES EN for_loop
        // ═══════════════════════════════════════════════════════
        
        gramatica.group("FOR_PARAMETROS", "PARENTESIS_ABRE FOR_INIT EXPRESION EXPRESION PARENTESIS_CIERRA",
            true, 1, "Error Sintáctico {1}: Se esperaba ';' entre condición e incremento en for_loop [#]");
        
        gramatica.group("FOR_PARAMETROS", "PARENTESIS_ABRE FOR_INIT EXPRESION PUNTO_COMA EXPRESION",
            true, 12, "Error Sintáctico {12}: Se esperaba ')' para cerrar los parámetros de for_loop [#]");
        
        gramatica.group("ESTRUCTURA_FOR", "FOR PARENTESIS_ABRE PARENTESIS_CIERRA BLOQUE",
            true, 24, "Error Sintáctico {24}: La estructura for_loop está vacía [#]");
        
        gramatica.group("ESTRUCTURA_FOR", "FOR BLOQUE",
            true, 24, "Error Sintáctico {24}: Se esperaban los parámetros '(init; cond; incr)' en for_loop [#]");
        
        gramatica.group("ESTRUCTURA_FOR", "FOR FOR_PARAMETROS SENTENCIAS",
            true, 10, "Error Sintáctico {10}: Se esperaba 'start_netrun' para abrir el bloque de for_loop [#]");

        // ═══════════════════════════════════════════════════════
        // GRUPO 7: PARÉNTESIS EN hack_print / neural_scan
        // ═══════════════════════════════════════════════════════
        
        gramatica.group("FUNCION_PRINT", "PRINT PARENTESIS_ABRE EXPRESION PUNTO_COMA",
            true, 12, "Error Sintáctico {12}: Se esperaba ')' para cerrar hack_print(...) [#]");
        
        gramatica.group("FUNCION_PRINT", "PRINT EXPRESION PARENTESIS_CIERRA PUNTO_COMA",
            true, 13, "Error Sintáctico {13}: Se esperaba '(' para abrir hack_print(...) [#]");
        
        gramatica.group("FUNCION_PRINT", "PRINT EXPRESION PUNTO_COMA",
            true, 13, "Error Sintáctico {13}: Se esperaban '(' y ')' en hack_print [#]");
        
        gramatica.group("FUNCION_SCAN", "SCAN PARENTESIS_ABRE IDENTIFICADOR PUNTO_COMA",
            true, 12, "Error Sintáctico {12}: Se esperaba ')' para cerrar neural_scan(...) [#]");
        
        gramatica.group("FUNCION_SCAN", "SCAN IDENTIFICADOR PARENTESIS_CIERRA PUNTO_COMA",
            true, 13, "Error Sintáctico {13}: Se esperaba '(' para abrir neural_scan(...) [#]");
        
        gramatica.group("FUNCION_SCAN", "SCAN IDENTIFICADOR PUNTO_COMA",
            true, 13, "Error Sintáctico {13}: Se esperaban '(' y ')' en neural_scan [#]");

        // ═══════════════════════════════════════════════════════
        // GRUPO 8: BLOQUES INCOMPLETOS
        // ═══════════════════════════════════════════════════════
        
        gramatica.group("BLOQUE", "START_BLOCK SENTENCIAS*",
            true, 11, "Error Sintáctico {11}: Se esperaba 'end_netrun' para cerrar el bloque [#]");

        // ═══════════════════════════════════════════════════════
        // GRUPO 9: PROGRAMA PRINCIPAL
        // ═══════════════════════════════════════════════════════
        
        gramatica.group("PROGRAMA", "MAIN SENTENCIAS",
            true, 10, "Error Sintáctico {10}: Se esperaba 'start_netrun' después de cybermain [#]");
        
        gramatica.group("PROGRAMA", "BLOQUE",
            true, 40, "Error Sintáctico {40}: Se esperaba 'cybermain' al inicio del programa [#]");

        // ═══════════════════════════════════════════════════════
        // GRUPO 10: EXPRESIONES INCOMPLETAS
        // ═══════════════════════════════════════════════════════
        
        gramatica.group("EXPRESION", "EXPRESION OP_ARITMETICO",
            true, 35, "Error Sintáctico {35}: Expresión aritmética incompleta — falta operando derecho [#]");
        
        gramatica.group("EXPRESION", "EXPRESION OP_RELACIONAL",
            true, 4, "Error Sintáctico {4}: Expresión relacional incompleta — falta operando derecho [#]");
        
        gramatica.group("EXPRESION", "EXPRESION OP_LOGICO",
            true, 36, "Error Sintáctico {36}: Expresión lógica incompleta — falta segundo operando [#]");

        // ═══════════════════════════════════════════════════════
        // GRUPO 11: TIPO DE DATO FALTANTE
        // ═══════════════════════════════════════════════════════
        
        gramatica.group("DECLARACION_CONSTANTE", "CONST IDENTIFICADOR ASIGNACION EXPRESION PUNTO_COMA",
            true, 31, "Error Sintáctico {31}: Se esperaba un tipo de dato después de 'const' [#]");
    }
    
    /**
     * Retorna el número total de errores encontrados
     */
    public int getNumeroErrores() {
        return errors.size();
    }
    
    /**
     * Retorna true si no hay errores
     */
    public boolean esValido() {
        return errors.isEmpty();
    }
}