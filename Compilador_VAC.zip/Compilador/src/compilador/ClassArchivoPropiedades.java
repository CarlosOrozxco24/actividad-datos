package compilador;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class ClassArchivoPropiedades {
    public Properties LeerPropiedades(){
        Properties config = new Properties();
        try{
            // Intenta leer del directorio actual
            FileInputStream configInput = new FileInputStream(System.getProperty("user.dir") + "/config.properties");
            config.load(configInput);
            configInput.close();
            return config;
        } catch(Exception e){
            return new Properties(); // Retorna propiedades vacías si falla
        }
    }

    public boolean EscribirPropiedades(Properties propiedades){
        try{
            FileOutputStream configOutput = new FileOutputStream(System.getProperty("user.dir") + "/config.properties");
            propiedades.store(configOutput, "<------ Configuraciones del Compilador ------>");
            configOutput.close();
            return true;
        } catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }

    public String LeerPropiedades(String llave) {
        Properties config = LeerPropiedades();
        return config.getProperty(llave);
    }
}