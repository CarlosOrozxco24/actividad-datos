/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package compilador;

/**
 * Clase Symbol mejorada para la tabla de símbolos
 * Almacena información completa de variables y constantes
 */
public class Symbol {
    public String id;           // Identificador de la variable
    public String tipo;         // Tipo de dato (INT, FLOAT, STRING_TYPE, etc.)
    public Object valor;        // Valor actual de la variable
    public boolean isConst;     // true si es constante, false si es variable
    public int lineaDec;        // Línea donde fue declarada
    public int columnaDecl;     // Columna donde fue declarada
    public String ambito;       // Ámbito (global, local, etc.)
    public boolean inicializada; // Si la variable ha sido inicializada

    // Constructor completo
    public Symbol(String id, String tipo, Object valor, boolean isConst, 
                  int lineaDec, int columnaDecl, String ambito) {
        this.id = id;
        this.tipo = tipo;
        this.valor = valor;
        this.isConst = isConst;
        this.lineaDec = lineaDec;
        this.columnaDecl = columnaDecl;
        this.ambito = ambito;
        this.inicializada = (valor != null);
    }

    // Constructor simplificado (retrocompatibilidad)
    public Symbol(String id, String tipo, Object valor, boolean isConst) {
        this(id, tipo, valor, isConst, 0, 0, "global");
    }

    /**
     * Actualiza el valor de la variable
     * @return true si se pudo actualizar, false si es constante
     */
    public boolean actualizarValor(Object nuevoValor) {
        if (isConst) {
            return false; // No se puede modificar una constante
        }
        this.valor = nuevoValor;
        this.inicializada = true;
        return true;
    }

    /**
     * Verifica si el símbolo es compatible con un tipo dado
     */
    public boolean esCompatibleCon(String otroTipo) {
        // Lógica básica de compatibilidad de tipos
        if (tipo.equals(otroTipo)) return true;
        
        // INT compatible con FLOAT (promoción implícita)
        if (tipo.equals("INT") && otroTipo.equals("FLOAT")) return true;
        
        return false;
    }

    @Override
    public String toString() {
        return String.format("%s | %s | %s | %s | Línea %d", 
                           id, 
                           tipo, 
                           valor != null ? valor.toString() : "sin inicializar", 
                           isConst ? "Const" : "Var",
                           lineaDec);
    }

    /**
     * Representación detallada para debugging
     */
    public String toDetailedString() {
        return String.format("Symbol{id='%s', tipo='%s', valor=%s, isConst=%b, " +
                           "linea=%d, columna=%d, ambito='%s', inicializada=%b}",
                           id, tipo, valor, isConst, lineaDec, columnaDecl, 
                           ambito, inicializada);
    }
}
