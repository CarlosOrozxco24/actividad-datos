package compilador;
 
import compilerTools.ErrorLSSL;
import compilerTools.Production;
import compilerTools.Token;
import java.util.ArrayList;
import java.util.HashSet;
 
/**
 * Analizador Semántico — Compilador Cyberpunk
 *
 * Siguiendo el patrón del maestro en dos etapas:
 *   ETAPA 1: recuperarSimbolos() — construir tabla de símbolos.
 *            Los errores de redeclaración (E2) y tipo en declaración (E4a)
 *            se detectan AQUÍ, antes del análisis semántico.
 *   ETAPA 2: analisisSemantico() — recorrer todas las producciones capturadas
 *            (asignaciones, funciones, condiciones) para detectar el resto.
 *
 * ERRORES DETECTADOS
 * ──────────────────────────────────────────────────────────────────────────
 * [E1]  Uso de identificador no declarado (asignaciones, RHS, print, scan,
 *       condiciones de if/while/for)
 * [E2]  Redeclaración en el mismo ámbito
 * [E3]  Uso de variable no inicializada
 * [E4a] Incompatibilidad de tipos — literal asignado a tipo distinto
 * [E4b] Incompatibilidad de tipos — variable de tipo diferente en asignación
 * [E5]  Operación aritmética sobre tipo booleano (logic) en declaración/asig
 * [E5c] Comparación inválida — operandos de tipos incomparables en OP_REL
 * [E6]  Asignación o reasignación a constante (edgerunner)
 * [E7]  Condición no booleana en if_net / while_sync
 */
public class AnalizadorSemantico {
 
    // Copia de tokens ANTES de la reducción gramatical
    private ArrayList<Token> tokensOriginales;
 
    public AnalizadorSemantico(ArrayList<Token> tokensOriginales) {
        this.tokensOriginales = tokensOriginales;
    }
 
    public AnalizadorSemantico() {
        this.tokensOriginales = new ArrayList<>();
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // MÉTODO PRINCIPAL — sigue el patrón del ejemplo de teams
    // ════════════════════════════════════════════════════════════════════════
 
    public void Analizar() {
        // ── ETAPA 1: Construir tabla de símbolos ─────────────────────────────
        // Errores E2 (redeclaración) y E4a (tipo en declaración) se generan aquí.
        recuperarSimbolos();
 
        // ── ETAPA 2: Análisis semántico sobre las producciones capturadas ────
        // Solo se ejecuta si la tabla ya fue construida correctamente.
        analisisSemantico();
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // ETAPA 1 — recuperarSimbolos()
    // ════════════════════════════════════════════════════════════════════════
 
    /**
     * Recorre los tokens ORIGINALES (antes de cualquier reducción gramatical)
     * para construir la tabla de símbolos.
     * Durante este proceso se detectan:
     *   [E2] Redeclaración de identificador en el mismo ámbito.
     *   [E4a] Tipo de valor incompatible en la declaración.
     */
    private void recuperarSimbolos() {
        if (!tokensOriginales.isEmpty()) {
            poblarDesdeTokensOriginales();
        } else {
            // Fallback: usar las producciones ya capturadas por la gramática
            poblarDesdeProduccionesGramaticales();
        }
    }
 
    // ── Escaneo directo de tokens originales ─────────────────────────────────
    private void poblarDesdeTokensOriginales() {
        int n = tokensOriginales.size();
        for (int i = 0; i < n; i++) {
            Token t  = tokensOriginales.get(i);
            String lc = t.getLexicalComp();
 
            // ── Detectar inicio de for_loop: FOR ( TIPO_DATO ... ──────────
            // for_loop (neural i = 0; ...) → la variable del init se debe
            // registrar como INT únicamente.
            if (lc.equals("FOR")) {
                i = procesarInicializacionFor(tokensOriginales, i);
                continue;
            }
 
            if (lc.equals("CONST_KW")) {
                i = procesarConstante(tokensOriginales, i);
            } else if (esTipoDato(lc)) {
                i = procesarDeclaracion(tokensOriginales, i);
            }
        }
    }
 
    /**
     * Procesa la sección de inicialización del for_loop:
     *   for_loop ( TIPO IDENT [= VALOR] ; condición ; incremento )
     *
     * Reglas semánticas:
     *   - Solo se permite INT (neural) o BYTE_TYPE (synthbyte) como tipo.
     *   - Si no tiene valor inicial, se asigna 0 (valor por defecto entero).
     *   - La variable se registra normalmente en la tabla de símbolos.
     *
     * Retorna el índice DESPUÉS del primer ';' de los args del for.
     */
    private int procesarInicializacionFor(ArrayList<Token> tokens, int posFor) {
        int n = tokens.size();
        int i = posFor + 1;
 
        // Saltar hasta el PARENTESIS_ABRE
        while (i < n && !tokens.get(i).getLexicalComp().equals("PARENTESIS_ABRE")) i++;
        if (i >= n) return posFor;
        i++; // saltar el '('
 
        // ¿El primer token dentro del ( es un tipo de dato?
        if (i >= n) return posFor;
        String lcTipo = tokens.get(i).getLexicalComp();
 
        if (esTipoDato(lcTipo)) {
            Token tipoTk = tokens.get(i);
 
            // [E4-FOR] Solo INT o BYTE_TYPE permitidos en el init del for
            if (!lcTipo.equals("INT") && !lcTipo.equals("BYTE_TYPE")) {
                Repositorio.errores.add(new ErrorLSSL(2,
                    "Error Sem\u00e1ntico [E4]: Solo se permiten enteros (neural/synthbyte) "
                    + "como variable de control en for_loop [#]", tipoTk));
            }
 
            // Avanzar al identificador
            if (i + 1 >= n) return posFor;
            Token identTk = tokens.get(i + 1);
            if (!identTk.getLexicalComp().equals("IDENTIFICADOR")) return posFor;
 
            String id   = identTk.getLexeme();
            Object valor = null; // se llenará si tiene '='
 
            // ¿Tiene '=' ?
            if (i + 2 < n && tokens.get(i + 2).getLexicalComp().equals("ASIGNACION")) {
                // Recolectar expresión hasta el PUNTO_COMA
                int j = i + 3;
                StringBuilder exprSb = new StringBuilder();
                while (j < n && !tokens.get(j).getLexicalComp().equals("PUNTO_COMA")) {
                    exprSb.append(tokens.get(j).getLexeme());
                    j++;
                }
                String exprStr = exprSb.toString().trim();
                valor = intentarParsear(exprStr, lcTipo);
                i = j; // i apunta al PUNTO_COMA
            } else {
                // Sin '=' → avanzar hasta el PUNTO_COMA
                while (i < n && !tokens.get(i).getLexicalComp().equals("PUNTO_COMA")) i++;
            }
 
            // Registrar en tabla (si ya existe, no es error para for: puede ser re-uso)
            if (!Repositorio.tablaSimbolos.containsKey(id)) {
                registrarEnTabla(id, lcTipo, valor, false, identTk);
            } else {
                // Re-declaración en otro for: actualizar valor sin reportar E2
                Symbol sym = Repositorio.tablaSimbolos.get(id);
                if (!sym.isConst) {
                    Object valorFinal = (valor != null) ? valor : obtenerValorPorDefecto(lcTipo);
                    sym.actualizarValor(valorFinal);
                }
            }
            return i; // continuar desde el primer ';' del for
        }
 
        return posFor; // no había declaración, dejar que el loop normal continúe
    }
 
    /**
     * Procesa:  edgerunner TIPO IDENT = VALOR ;
     * Detecta:  [E2] redeclaración, [E4a] tipo incompatible en constante.
     */
    private int procesarConstante(ArrayList<Token> tokens, int pos) {
        int n = tokens.size();
        if (pos + 4 >= n) return pos;
 
        Token tipoTk  = tokens.get(pos + 1);
        Token identTk = tokens.get(pos + 2);
        Token asigTk  = tokens.get(pos + 3);
        Token valTk   = tokens.get(pos + 4);
 
        if (!esTipoDato(tipoTk.getLexicalComp()))            return pos;
        if (!identTk.getLexicalComp().equals("IDENTIFICADOR")) return pos;
        if (!asigTk.getLexicalComp().equals("ASIGNACION"))     return pos;
 
        String tipo = tipoTk.getLexicalComp();
 
        // [E4a] Verificar compatibilidad del valor literal asignado
        if (esLiteralToken(valTk.getLexicalComp())) {
            String tipoValor = lexCompATipo(valTk.getLexicalComp());
            if (!tipoValor.equals("UNKNOWN") && !sonCompatibles(tipo, tipoValor)) {
                Repositorio.errores.add(new ErrorLSSL(2,
                    "Error Semántico [E4]: Tipo incompatible en constante '"
                    + identTk.getLexeme() + "' — se declaró "
                    + labelTipo(tipo) + " pero el valor es "
                    + labelTipo(tipoValor) + " [#]", valTk));
            }
        }
 
        Object valor = obtenerValorDeToken(valTk);
        registrarEnTabla(identTk.getLexeme(), tipo, valor, true, identTk);
 
        return pos + 4;
    }
 
    /**
     * Procesa:  TIPO IDENT [= EXPR] [, IDENT [= EXPR]]* ;
     * Detecta:  [E2] redeclaración, [E4a] tipo incompatible en declaración.
     */
    private int procesarDeclaracion(ArrayList<Token> tokens, int pos) {
        int n = tokens.size();
        String tipo = tokens.get(pos).getLexicalComp();
        int i = pos + 1;
 
        while (i < n) {
            Token t  = tokens.get(i);
            String lc = t.getLexicalComp();
 
            if (lc.equals("PUNTO_COMA")) return i;
            if (lc.equals("COMA"))       { i++; continue; }
 
            if (lc.equals("IDENTIFICADOR")) {
                String id = t.getLexeme();
 
                // ¿Tiene valor inicial?
                if (i + 1 < n && tokens.get(i + 1).getLexicalComp().equals("ASIGNACION")) {
                    i += 2;  // saltar IDENT y '='
                    StringBuilder expr = new StringBuilder();
                    Token primerValTk = null;
                    ArrayList<Token> rhsTokenList = new ArrayList<>();
                    int depth = 0;
 
                    while (i < n) {
                        String lc2 = tokens.get(i).getLexicalComp();
                        if (lc2.equals("PARENTESIS_ABRE"))   depth++;
                        if (lc2.equals("PARENTESIS_CIERRA")) { depth--; }
                        if (depth == 0 && (lc2.equals("COMA") || lc2.equals("PUNTO_COMA"))) break;
                        if (primerValTk == null) primerValTk = tokens.get(i);
                        expr.append(tokens.get(i).getLexeme());
                        rhsTokenList.add(tokens.get(i));
                        i++;
                    }
 
                    String exprStr = expr.toString().trim();
 
                    // [E4a] Literal simple incompatible con el tipo declarado
                    // Ej: neural x = 3.14;  logic b = 42;
                    if (primerValTk != null && esLiteralToken(primerValTk.getLexicalComp())
                            && exprStr.equals(primerValTk.getLexeme())) {
                        String tipoValor = lexCompATipo(primerValTk.getLexicalComp());
                        if (!tipoValor.equals("UNKNOWN") && !sonCompatibles(tipo, tipoValor)) {
                            Repositorio.errores.add(new ErrorLSSL(2,
                                "Error Semántico [E4]: Tipo incompatible en '"
                                + id + "' — se declaró " + labelTipo(tipo)
                                + " pero se asigna " + labelTipo(tipoValor)
                                + " (" + exprStr + ") [#]", t));
                        }
                    }
 
                    // [E4b] Identificador simple de tipo incompatible
                    // Ej: neural mal2 = pi;  donde pi es floatwave → FLOAT→INT error
                    // El check de E4a no lo cubre porque pi NO es un literal.
                    if (primerValTk != null
                            && primerValTk.getLexicalComp().equals("IDENTIFICADOR")
                            && exprStr.equals(primerValTk.getLexeme())) {
                        String idRHS = primerValTk.getLexeme();
                        if (Repositorio.tablaSimbolos.containsKey(idRHS)) {
                            String tipoRHS = Repositorio.tablaSimbolos.get(idRHS).tipo;
                            if (!sonCompatibles(tipo, tipoRHS)) {
                                Repositorio.errores.add(new ErrorLSSL(2,
                                    "Error Semántico [E4]: Tipo incompatible en '"
                                    + id + "' — se declaró " + labelTipo(tipo)
                                    + " pero '" + idRHS + "' es " + labelTipo(tipoRHS)
                                    + " [#]", primerValTk));
                            }
                        }
                    }
 
                    // [E4c] Expresión aritmética cuyo tipo dominante es incompatible
                    // Ej: neural malos = mal1 + pi;  (INT + FLOAT = FLOAT → no cabe en INT)
                    //     neural x = 2.5 * 2;        (FLOAT * INT = FLOAT → no cabe en INT)
                    if (contieneOperadorAritmeticoToken(exprStr)) {
                        ArrayList<Token> rhsToks = new ArrayList<>();
                        for (int ri = 0; ri < rhsTokenList.size(); ri++) rhsToks.add(rhsTokenList.get(ri));
                        String tipoExpr = inferirTipoExpresion(rhsToks);
                        if (!tipoExpr.equals("UNKNOWN") && !sonCompatibles(tipo, tipoExpr)) {
                            Repositorio.errores.add(new ErrorLSSL(2,
                                "Error Semántico [E4]: Tipo incompatible en '"
                                + id + "' — se declaró " + labelTipo(tipo)
                                + " pero la expresión produce " + labelTipo(tipoExpr)
                                + " [#]", t));
                        }
                    }
 
                    // [E5] Tipos inválidos en operación aritmética del RHS
                    // Ej: neural x = 'A' + 5;  logic b = samurai + punk;
                    if (contieneOperadorAritmeticoToken(exprStr)) {
                        for (Token rTk : rhsTokenList) {
                            String lcR = rTk.getLexicalComp();
                            if (lcR.equals("CARACTER")) {
                                Repositorio.errores.add(new ErrorLSSL(2,
                                    "Error Semántico [E5]: charbyte (carácter) '"
                                    + rTk.getLexeme() + "' no puede usarse en operación "
                                    + "aritmética en '" + id + "' [#]", rTk)); break;
                            }
                            if (lcR.equals("CADENA")) {
                                Repositorio.errores.add(new ErrorLSSL(2,
                                    "Error Semántico [E5]: datastring "
                                    + rTk.getLexeme() + " no puede usarse en operación "
                                    + "aritmética en '" + id + "' [#]", rTk)); break;
                            }
                            if (lcR.equals("CONST_SAMURAI") || lcR.equals("CONST_PUNK")) {
                                Repositorio.errores.add(new ErrorLSSL(2,
                                    "Error Semántico [E5]: logic (booleano) '"
                                    + rTk.getLexeme() + "' no puede usarse en operación "
                                    + "aritmética en '" + id + "' [#]", rTk)); break;
                            }
                            if (lcR.equals("IDENTIFICADOR")) {
                                String rId = rTk.getLexeme();
                                if (Repositorio.tablaSimbolos.containsKey(rId)) {
                                    String rTipoV = Repositorio.tablaSimbolos.get(rId).tipo;
                                    if (rTipoV.equals("BOOL_TYPE") || rTipoV.equals("CHAR_TYPE")
                                            || rTipoV.equals("STRING_TYPE")) {
                                        Repositorio.errores.add(new ErrorLSSL(2,
                                            "Error Semántico [E5]: '" + rId + "' es "
                                            + labelTipo(rTipoV) + " y no puede usarse en "
                                            + "operación aritmética en '"
                                            + id + "' [#]", rTk)); break;
                                    }
                                }
                            }
                        }
                    }
 
                    // [E5] Operación aritmética asignada a variable booleana
                    if (tipo.equals("BOOL_TYPE") && contieneOperadorAritmetico(exprStr)) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E5]: Operación aritmética inválida sobre "
                            + "variable booleana '" + id + "' [#]", t));
                    }
 
                    Object valor = intentarParsear(exprStr, tipo);
                    registrarEnTabla(id, tipo, valor, false, t);
                    continue; // i ya apunta a COMA o PUNTO_COMA
                }
 
                // Sin valor inicial → no inicializada (inicializada = false en Symbol)
                registrarEnTabla(id, tipo, null, false, t);
            }
            i++;
        }
        return i;
    }
 
    /**
     * Registra el símbolo en Repositorio.tablaSimbolos.
     * Detecta [E2] redeclaración.
     */
    private void registrarEnTabla(String id, String tipo, Object valor,
                                   boolean esConst, Token refToken) {
        if (Repositorio.tablaSimbolos.containsKey(id)) {
            // [E2] Variable ya declarada en el mismo ámbito
            Symbol existente = Repositorio.tablaSimbolos.get(id);
            Repositorio.errores.add(new ErrorLSSL(2,
                "Error Semántico [E2]: '" + id + "' ya fue declarado en línea "
                + existente.lineaDec + " [#]", refToken));
        } else {
            // Si no hay valor explícito, usar el valor por defecto del tipo
            // (0, 0.0, false, ' ', "") para mostrarlo en la tabla de símbolos.
            // Se marca inicializada=false para que [E3] siga detectando usos
            // antes de una asignación real del programador.
            boolean fueAsignada = (valor != null);
            Object valorFinal   = fueAsignada ? valor : obtenerValorPorDefecto(tipo);
            Symbol sym = new Symbol(id, tipo, valorFinal, esConst,
                           refToken.getLine(), refToken.getColumn(), "global");
            if (!fueAsignada && !esConst) sym.inicializada = false;
            Repositorio.tablaSimbolos.put(id, sym);
        }
    }
 
    /** Valor semántico por defecto según el tipo del lenguaje Cyberpunk. */
    private Object obtenerValorPorDefecto(String tipo) {
        switch (tipo) {
            case "INT":         return 0;
            case "FLOAT":       return 0.0f;
            case "STRING_TYPE": return "";
            case "CHAR_TYPE":   return ' ';
            case "BOOL_TYPE":   return false;
            case "BYTE_TYPE":   return 0;
            default:            return 0;
        }
    }
 
    // ── Fallback: usar producciones gramaticales ──────────────────────────────
    private void poblarDesdeProduccionesGramaticales() {
        // Declaraciones: TIPO_DATO EXPRESION [ASIGNACION EXPRESION] PUNTO_COMA
        for (Production p : Repositorio.declaraciones) {
            if (p.getSizeTokens() < 2) continue;
            String tipo  = p.lexicalCompRank(0); // "INT", "FLOAT", etc.
            String ident = p.lexemeRank(1);       // nombre del identificador
            Object valor = null;
            if (p.getSizeTokens() > 3 && "ASIGNACION".equals(p.lexicalCompRank(2))) {
                valor = intentarParsear(p.lexemeRank(3), tipo);
            }
            if (!Repositorio.tablaSimbolos.containsKey(ident)) {
                Repositorio.tablaSimbolos.put(ident,
                    new Symbol(ident, tipo, valor, false,
                               p.getLine(), p.getColumn(), "global"));
            }
        }
        // Constantes: CONST_KW TIPO_DATO EXPRESION ASIGNACION EXPRESION PUNTO_COMA
        for (Production p : Repositorio.constantes) {
            if (p.getSizeTokens() < 5) continue;
            String tipo  = p.lexicalCompRank(1);
            String ident = p.lexemeRank(2);
            Object valor = intentarParsear(p.lexemeRank(4), tipo);
            if (!Repositorio.tablaSimbolos.containsKey(ident)) {
                Repositorio.tablaSimbolos.put(ident,
                    new Symbol(ident, tipo, valor, true,
                               p.getLine(), p.getColumn(), "global"));
            }
        }
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // ETAPA 2 — analisisSemantico()
    // ════════════════════════════════════════════════════════════════════════
 
    /**
     * Recorre todas las producciones capturadas por la gramática para
     * detectar errores semánticos en su uso.
     */
    private void analisisSemantico() {
 
        // ── ASIGNACIONES: x = expr; / x += expr; / x++; / ++x; ─────────────
        // Estructura en Repositorio.asignaciones:
        //   [0]=EXPRESION(LHS)  [1]=ASIGNACION  [2]=EXPRESION(RHS)  [3]=;
        //   [0]=EXPRESION(LHS)  [1]=OP_COMP     [2]=EXPRESION(RHS)  [3]=;
        //   [0]=EXPRESION(LHS)  [1]=OP_INC      [2]=;
        //   [0]=OP_INC          [1]=EXPRESION(LHS) [2]=;
        for (Production asig : Repositorio.asignaciones) {
            if (asig.getSizeTokens() < 2) continue;
 
            // Determinar posición del identificador LHS y si tiene RHS
            boolean tieneRHS = false;
            int posLHS   = 0;
            int posRHS   = -1;
            String lc0   = asig.lexicalCompRank(0);
 
            if (lc0.equals("OP_INC")) {
                // ++x;  o  --x;  → LHS en posición 1
                posLHS = 1;
            } else {
                // x = ... / x++ → LHS en posición 0
                posLHS = 0;
                if (asig.getSizeTokens() >= 3) {
                    String lc1 = asig.lexicalCompRank(1);
                    if (lc1.equals("ASIGNACION") || lc1.equals("OP_COMP")) {
                        tieneRHS = true;
                        posRHS   = 2;
                    }
                }
            }
 
            String identLHS = asig.lexemeRank(posLHS);
            Token  refLHS   = asig.getTokens().get(posLHS);
 
            // [E1] LHS no declarado
            if (!Repositorio.tablaSimbolos.containsKey(identLHS)) {
                Repositorio.errores.add(new ErrorLSSL(2,
                    "Error Semántico [E1]: Variable '" + identLHS
                    + "' usada sin ser declarada [#]", refLHS));
                continue; // no tiene caso verificar más sobre esta variable
            }
 
            Symbol sym = Repositorio.tablaSimbolos.get(identLHS);
 
            // [E6] Asignación a constante
            if (sym.isConst) {
                Repositorio.errores.add(new ErrorLSSL(2,
                    "Error Semántico [E6]: No se puede reasignar la constante '"
                    + identLHS + "' [#]", refLHS));
                continue;
            }
 
            if (tieneRHS) {
                String lexRHS = asig.lexemeRank(posRHS);
                Token  refRHS = asig.getTokens().get(posRHS);
 
                // [E1] Identificador en RHS no declarado (solo si es un nombre simple)
                if (pareceLexemaIdentificador(lexRHS)) {
                    if (!Repositorio.tablaSimbolos.containsKey(lexRHS)) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E1]: Identificador '" + lexRHS
                            + "' usado sin ser declarado [#]", refRHS));
                    } else {
                        // [E3] Identificador en RHS no inicializado
                        Symbol symRHS = Repositorio.tablaSimbolos.get(lexRHS);
                        if (!symRHS.inicializada) {
                            Repositorio.errores.add(new ErrorLSSL(2,
                                "Error Semántico [E3]: Variable '" + lexRHS
                                + "' usada sin haber sido inicializada [#]", refRHS));
                        }
                        // [E4b] Tipo incompatible — RHS es variable de distinto tipo
                        // Ej: floatwave pi = 3.14;  neural n = pi;  ← FLOAT→INT error
                        // SAFE: solo dispara si los tipos son realmente incompatibles;
                        // sonCompatibles() ya permite INT←BYTE, FLOAT←INT, etc.
                        if (!sonCompatibles(sym.tipo, symRHS.tipo)) {
                            Repositorio.errores.add(new ErrorLSSL(2,
                                "Error Sem\u00e1ntico [E4]: Tipo incompatible en asignaci\u00f3n — '"
                                + identLHS + "' es " + labelTipo(sym.tipo)
                                + " pero '" + lexRHS + "' es " + labelTipo(symRHS.tipo)
                                + " [#]", refRHS));
                        }
                    }
                }
 
                // [E4] Tipo incompatible en asignación (solo para literal simple)
                String tipoValor = inferirTipoDeLexema(lexRHS);
                if (!tipoValor.equals("UNKNOWN") && !sonCompatibles(sym.tipo, tipoValor)) {
                    Repositorio.errores.add(new ErrorLSSL(2,
                        "Error Semántico [E4]: Tipo incompatible — '"
                        + identLHS + "' es " + labelTipo(sym.tipo)
                        + " pero se asigna un valor de tipo "
                        + labelTipo(tipoValor) + " [#]", refLHS));
                }
 
                // [E5] Operación aritmética en variable booleana
                if (sym.tipo.equals("BOOL_TYPE") && asig.lexicalCompRank(1).equals("ASIGNACION")) {
                    if (contieneOperadorAritmetico(lexRHS)) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E5]: Operación aritmética inválida "
                            + "sobre variable booleana '" + identLHS + "' [#]", refLHS));
                    }
                }
 
                // Actualizar valor en tabla → marca inicializada = true
                sym.actualizarValor(lexRHS);
            } else {
                // x++;  x--;  — marcar como inicializada (si no lo estaba)
                // [E3] Incrementar variable no inicializada
                if (!sym.inicializada) {
                    Repositorio.errores.add(new ErrorLSSL(2,
                        "Error Semántico [E3]: Variable '" + identLHS
                        + "' incrementada/decrementada sin haber sido inicializada [#]", refLHS));
                } else {
                    sym.actualizarValor(sym.valor + "++"); // actualización simbólica
                }
            }
        }
 
        // ── SENTENCIAS PRINT: hack_print(EXPRESION); ─────────────────────────
        // Estructura: [0]=PRINT  [1]=EXPRESION(argumento)  [2]=;
        for (Production print : Repositorio.funciones) {
            if (print.getSizeTokens() < 2) continue;
            String lcFn = print.lexicalCompRank(0);
            if (!lcFn.equals("PRINT")) continue;
 
            String argLexema = print.lexemeRank(1);
            Token  argToken  = print.getTokens().get(1);
 
            if (pareceLexemaIdentificador(argLexema)) {
                // [E1] Identificador en hack_print no declarado
                if (!Repositorio.tablaSimbolos.containsKey(argLexema)) {
                    Repositorio.errores.add(new ErrorLSSL(2,
                        "Error Semántico [E1]: Identificador '" + argLexema
                        + "' en hack_print no fue declarado [#]", argToken));
                } else {
                    // [E3] Variable en hack_print no inicializada
                    Symbol s = Repositorio.tablaSimbolos.get(argLexema);
                    if (!s.inicializada) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E3]: Variable '" + argLexema
                            + "' usada en hack_print sin haber sido inicializada [#]",
                            argToken));
                    }
                }
            }
        }
 
        // ── SENTENCIAS SCAN: neural_scan(EXPRESION); ─────────────────────────
        // Estructura: [0]=SCAN  [1]=EXPRESION(variable destino)  [2]=;
        for (Production scan : Repositorio.funciones) {
            if (scan.getSizeTokens() < 2) continue;
            String lcFn = scan.lexicalCompRank(0);
            if (!lcFn.equals("SCAN")) continue;
 
            String varLexema = scan.lexemeRank(1);
            Token  varToken  = scan.getTokens().get(1);
 
            if (pareceLexemaIdentificador(varLexema)) {
                // [E1] Variable en neural_scan no declarada
                if (!Repositorio.tablaSimbolos.containsKey(varLexema)) {
                    Repositorio.errores.add(new ErrorLSSL(2,
                        "Error Semántico [E1]: Identificador '" + varLexema
                        + "' en neural_scan no fue declarado [#]", varToken));
                } else {
                    Symbol s = Repositorio.tablaSimbolos.get(varLexema);
                    if (s.isConst) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E6]: No se puede usar neural_scan sobre la constante '"
                            + varLexema + "' — las constantes no pueden modificarse [#]", varToken));
                    } else if (s.tipo.equals("BOOL_TYPE")) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E8]: neural_scan no puede leer hacia '"
                            + varLexema + "' porque es logic (booleano) [#]", varToken));
                    } else if (s.tipo.equals("CHAR_TYPE")) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E8]: neural_scan no puede leer hacia '"
                            + varLexema + "' porque es charbyte (carácter) [#]", varToken));
                    } else {
                        s.inicializada = true;
                    }
                }
            }
        }
 
        // ── ASIGNACIONES COMPLEJAS (expresiones con variables e identificadores) ──
        // Detecta [E4] cuando pi+1 (FLOAT) se asigna a neural (INT), etc.
        validarAsignacionesComplejas();
 
        // ── INCREMENTOS EN FOR-LOOP ─────────────────────────────────────────────
        validarIncrementoFor();
 
        // ── NOT SOBRE TIPO NO BOOLEANO ───────────────────────────────────────
        validarOperadorNot();
 
        // ── CONDICIONES DE CONTROL: if_net / while_sync / for_loop ──────────
        validarCondicionesDeControl();
 
        // ── IDENTIFICADORES EN CUALQUIER USO (escaneo de tokens originales) ──
        // Recorre tokensOriginales para encontrar IDENTIFICADORs usados fuera
        // de su declaración: condiciones de if/while/for, RHS complejos, etc.
        // Detecta [E1] y [E3] en todos esos contextos.
        validarUsosGeneralesEnTokens();
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // Escaneo general de tokens — detecta [E1] y [E3] en TODOS los contextos
    // ════════════════════════════════════════════════════════════════════════
 
    /**
     * Recorre tokensOriginales identificando todos los IDENTIFICADOR que
     * aparecen en posición de USO (no de declaración) y verifica:
     *   [E1] ¿Está declarado?
     *   [E3] ¿Fue inicializado antes de este uso?
     *
     * Contextos cubiertos: RHS de asignaciones con expresiones complejas,
     * condiciones de if/while/for, argumentos de hack_print/neural_scan.
     */
    private void validarUsosGeneralesEnTokens() {
        int n = tokensOriginales.size();
        // Set de líneas ya reportadas (para evitar duplicar errores del método anterior)
        HashSet<String> yaReportados = new HashSet<>();
 
        for (int i = 0; i < n; i++) {
            Token t  = tokensOriginales.get(i);
            String lc = t.getLexicalComp();
 
            // ── Saltar bloque de declaración: CONST_KW TIPO IDENT = VALOR ; ──
            if (lc.equals("CONST_KW")) {
                while (i < n && !tokensOriginales.get(i).getLexicalComp().equals("PUNTO_COMA")) i++;
                continue;
            }
 
            // ── Saltar init del for: FOR ( TIPO IDENT = VALOR ; ──────────────
            // Ya fue procesado por procesarInicializacionFor. Solo saltamos
            // hasta el primer ';' para que el validador no chequee la declaración.
            if (lc.equals("FOR")) {
                // Avanzar hasta PARENTESIS_ABRE
                while (i < n && !tokensOriginales.get(i).getLexicalComp().equals("PARENTESIS_ABRE")) i++;
                // Si lo que sigue es TIPO_DATO, saltar hasta el primer ';'
                if (i + 1 < n && esTipoDato(tokensOriginales.get(i + 1).getLexicalComp())) {
                    while (i < n && !tokensOriginales.get(i).getLexicalComp().equals("PUNTO_COMA")) i++;
                }
                continue;
            }
 
            // ── Bloque de declaración: saltar LHS, validar identificadores en RHS ──
            // ANTES se saltaba la línea entera → los ids no declarados en RHS se escapaban.
            if (esTipoDato(lc)) {
                boolean enRHS = false;
                i++; // saltar el tipo (neural, floatwave, etc.)
                while (i < n) {
                    String lc2 = tokensOriginales.get(i).getLexicalComp();
                    if (lc2.equals("PUNTO_COMA"))  break;
                    if (lc2.equals("ASIGNACION"))  { enRHS = true;  i++; continue; }
                    if (lc2.equals("COMA"))        { enRHS = false; i++; continue; }
                    if (lc2.equals("IDENTIFICADOR")) {
                        String id2  = tokensOriginales.get(i).getLexeme();
                        String key2 = id2 + "@" + tokensOriginales.get(i).getLine();
                        if (!enRHS) {
                            yaReportados.add(key2); // LHS: se está declarando → no chequear como uso
                        } else if (!yaReportados.contains(key2)) {
                            if (!Repositorio.tablaSimbolos.containsKey(id2)) {
                                boolean dup = false;
                                for (ErrorLSSL e : Repositorio.errores)
                                    if (e.getLine() == tokensOriginales.get(i).getLine()
                                            && e.toString().contains(id2)) { dup = true; break; }
                                if (!dup) {
                                    Repositorio.errores.add(new ErrorLSSL(2,
                                        "Error Semántico [E1]: Identificador '" + id2
                                        + "' usado sin ser declarado [#]", tokensOriginales.get(i)));
                                    yaReportados.add(key2);
                                }
                            } else {
                                Symbol s2 = Repositorio.tablaSimbolos.get(id2);
                                if (!s2.inicializada) {
                                    boolean dup = false;
                                    for (ErrorLSSL e : Repositorio.errores)
                                        if (e.getLine() == tokensOriginales.get(i).getLine()
                                                && e.toString().contains(id2)
                                                && e.toString().contains("[E3]")) { dup = true; break; }
                                    if (!dup) {
                                        Repositorio.errores.add(new ErrorLSSL(2,
                                            "Error Semántico [E3]: Variable '" + id2
                                            + "' usada sin haber sido inicializada [#]",
                                            tokensOriginales.get(i)));
                                        yaReportados.add(key2);
                                    }
                                }
                            }
                        }
                    }
                    i++;
                }
                continue; // i apunta al ';', el for i++ lo saltará
            }
 
            // ── Identificador en posición de USO ────────────────────────────
            if (lc.equals("IDENTIFICADOR")) {
                String id  = t.getLexeme();
                String key = id + "@" + t.getLine(); // clave única para deduplicar
 
                if (yaReportados.contains(key)) continue;
 
                if (!Repositorio.tablaSimbolos.containsKey(id)) {
                    // [E1] No declarado
                    // Solo reportar si no fue ya reportado por analisisSemantico()
                    boolean yaExisteError = false;
                    for (ErrorLSSL e : Repositorio.errores) {
                        if (e.getLine() == t.getLine() && e.toString().contains(id)) {
                            yaExisteError = true;
                            break;
                        }
                    }
                    if (!yaExisteError) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E1]: Identificador '" + id
                            + "' usado sin ser declarado [#]", t));
                        yaReportados.add(key);
                    }
                } else {
                    Symbol s = Repositorio.tablaSimbolos.get(id);
                    if (!s.inicializada) {
                        // [E3] Usado sin inicializar — solo reportar si no hay error previo
                        boolean yaExisteError = false;
                        for (ErrorLSSL e : Repositorio.errores) {
                            if (e.getLine() == t.getLine() && e.toString().contains(id)
                                    && e.toString().contains("[E3]")) {
                                yaExisteError = true;
                                break;
                            }
                        }
                        if (!yaExisteError) {
                            Repositorio.errores.add(new ErrorLSSL(2,
                                "Error Semántico [E3]: Variable '" + id
                                + "' usada sin haber sido inicializada [#]", t));
                            yaReportados.add(key);
                        }
                    }
                }
            }
        }
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // E7 y E5c — Validación de condiciones en if_net / while_sync
    // ════════════════════════════════════════════════════════════════════════
 
    /**
     * Recorre tokensOriginales buscando IF y WHILE, extrae la condición entre
     * paréntesis y valida:
     *   [E7]  Condición no booleana: if_net(42), while_sync(3.14), if_net(nombre)
     *         donde nombre es de tipo no booleano.
     *   [E5c] Comparación inválida: operandos de tipos incomparables alrededor
     *         de un OP_REL — ej: 5 < samurai,  miFloat > samurai.
     *
     * SAFE: no toca ninguna otra validación; solo lee tokensOriginales.
     */
    private void validarCondicionesDeControl() {
        int n = tokensOriginales.size();
 
        for (int i = 0; i < n; i++) {
            String lc = tokensOriginales.get(i).getLexicalComp();
            if (!lc.equals("IF") && !lc.equals("WHILE") && !lc.equals("FOR")) continue;
 
            // FOR: condición está entre el 1er y 2do ';' dentro del '()'
            if (lc.equals("FOR")) {
                i = validarCondicionFor(i);
                continue;
            }
 
            Token estructuraTk   = tokensOriginales.get(i);
            String nombreEstruc  = lc.equals("IF") ? "if_net" : "while_sync";
 
            // Buscar el '(' de la condición (puede haber espacio)
            int j = i + 1;
            while (j < n && !tokensOriginales.get(j).getLexicalComp().equals("PARENTESIS_ABRE")) j++;
            if (j >= n) continue;
            j++; // saltar el '('
 
            // Recolectar tokens de la condición respetando paréntesis anidados
            ArrayList<Token> cond = new ArrayList<>();
            int depth = 1;
            while (j < n && depth > 0) {
                String lc2 = tokensOriginales.get(j).getLexicalComp();
                if (lc2.equals("PARENTESIS_ABRE"))   depth++;
                if (lc2.equals("PARENTESIS_CIERRA")) { depth--; if (depth == 0) break; }
                cond.add(tokensOriginales.get(j));
                j++;
            }
            if (cond.isEmpty()) { i = j; continue; }
 
            // ── [E7] Condición de UN SOLO token que no es booleano ───────────
            if (cond.size() == 1) {
                Token condTk   = cond.get(0);
                String lcCondTk = condTk.getLexicalComp();
 
                // Literal numérico / cadena / char como condición directa
                if (lcCondTk.equals("ENTERO") || lcCondTk.equals("FLOTANTE")
                        || lcCondTk.equals("CADENA") || lcCondTk.equals("CARACTER")) {
                    Repositorio.errores.add(new ErrorLSSL(2,
                        "Error Sem\u00e1ntico [E7]: La condici\u00f3n de '"
                        + nombreEstruc + "' no es booleana — se encontr\u00f3 un "
                        + labelTipoPorLexComp(lcCondTk) + " literal [#]", condTk));
                }
                // Identificador de tipo no booleano como condición directa
                else if (lcCondTk.equals("IDENTIFICADOR")) {
                    String id = condTk.getLexeme();
                    if (Repositorio.tablaSimbolos.containsKey(id)) {
                        Symbol s = Repositorio.tablaSimbolos.get(id);
                        if (!s.tipo.equals("BOOL_TYPE")) {
                            Repositorio.errores.add(new ErrorLSSL(2,
                                "Error Sem\u00e1ntico [E7]: La condici\u00f3n de '"
                                + nombreEstruc + "' no es booleana — '"
                                + id + "' es " + labelTipo(s.tipo) + " [#]", condTk));
                        }
                    }
                }
            }
 
            // ── [E5c] Comparación inválida dentro de la condición ─────────────
            // FIX: en tokensOriginales NO existe "OP_REL" — la gramática crea ese
            // token al reducir, pero aquí trabajamos con MAYOR, MENOR, IGUAL_IGUAL, etc.
            for (int k = 0; k < cond.size(); k++) {
                if (!esOperadorRelacional(cond.get(k).getLexicalComp())) continue;
                // Operando izquierdo: retroceder ignorando ')' y NOT
                int ki = k - 1;
                while (ki >= 0 && (cond.get(ki).getLexicalComp().equals("PARENTESIS_CIERRA")
                        || cond.get(ki).getLexicalComp().equals("NOT"))) ki--;
                // Operando derecho: avanzar ignorando '(' y NOT
                int kd = k + 1;
                while (kd < cond.size() && (cond.get(kd).getLexicalComp().equals("PARENTESIS_ABRE")
                        || cond.get(kd).getLexicalComp().equals("NOT"))) kd++;
                if (ki < 0 || kd >= cond.size()) continue;
 
                String tipoIzq = inferirTipoDeToken(cond.get(ki));
                String tipoDer = inferirTipoDeToken(cond.get(kd));
 
                if (!tipoIzq.equals("UNKNOWN") && !tipoDer.equals("UNKNOWN")
                        && !sonComparables(tipoIzq, tipoDer)) {
                    Repositorio.errores.add(new ErrorLSSL(2,
                        "Error Semántico [E5c]: Comparación inválida entre "
                        + labelTipo(tipoIzq) + " (" + cond.get(ki).getLexeme() + ") y "
                        + labelTipo(tipoDer) + " (" + cond.get(kd).getLexeme() + ")"
                        + " en condición de '" + nombreEstruc + "' [#]",
                        cond.get(k)));
                }
            }
 
            i = j; // Avanzar más allá de la condición ya procesada
        }
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // E6 en incremento del for_loop — constante++ / ++constante en for(;;INC)
    // ════════════════════════════════════════════════════════════════════════
 
    private void validarIncrementoFor() {
        int n = tokensOriginales.size();
        for (int i = 0; i < n; i++) {
            if (!tokensOriginales.get(i).getLexicalComp().equals("FOR")) continue;
            int j = i + 1;
            while (j < n && !tokensOriginales.get(j).getLexicalComp().equals("PARENTESIS_ABRE")) j++;
            if (j >= n) continue;
            j++;
            int puntosComa = 0, depth = 1;
            while (j < n && depth > 0) {
                String lc2 = tokensOriginales.get(j).getLexicalComp();
                if (lc2.equals("PARENTESIS_ABRE"))   depth++;
                if (lc2.equals("PARENTESIS_CIERRA")) { depth--; if (depth==0) break; }
                if (lc2.equals("PUNTO_COMA") && depth == 1) {
                    puntosComa++;
                    if (puntosComa == 2) { j++; break; }
                }
                j++;
            }
            ArrayList<Token> inc = new ArrayList<>();
            while (j < n) {
                String lc2 = tokensOriginales.get(j).getLexicalComp();
                if (lc2.equals("PARENTESIS_CIERRA")) break;
                inc.add(tokensOriginales.get(j));
                j++;
            }
            for (int k = 0; k < inc.size(); k++) {
                if (!inc.get(k).getLexicalComp().equals("IDENTIFICADOR")) continue;
                String lexInc = inc.get(k).getLexeme();
                boolean modifica = false;
                if (k + 1 < inc.size()) {
                    String lcSig = inc.get(k+1).getLexicalComp();
                    if (lcSig.equals("INCREMENTO") || lcSig.equals("DECREMENTO")
                            || lcSig.equals("SUMA_ASIGNACION") || lcSig.equals("RESTA_ASIGNACION")
                            || lcSig.equals("MULTIPLICACION_ASIGNACION")
                            || lcSig.equals("DIVISION_ASIGNACION")
                            || lcSig.equals("ASIGNACION")) modifica = true;
                }
                if (!modifica && k > 0) {
                    String lcAnt = inc.get(k-1).getLexicalComp();
                    if (lcAnt.equals("INCREMENTO") || lcAnt.equals("DECREMENTO")) modifica = true;
                }
                if (modifica && Repositorio.tablaSimbolos.containsKey(lexInc)) {
                    Symbol s = Repositorio.tablaSimbolos.get(lexInc);
                    if (s.isConst) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E6]: No se puede modificar la constante '"
                            + lexInc + "' en el incremento de for_loop [#]", inc.get(k)));
                    }
                }
            }
            i = j;
        }
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // E9 — Operador NOT (!) sobre tipo no booleano
    // ════════════════════════════════════════════════════════════════════════
 
    private void validarOperadorNot() {
        int n = tokensOriginales.size();
        for (int i = 0; i < n - 1; i++) {
            if (!tokensOriginales.get(i).getLexicalComp().equals("NOT")) continue;
            Token sig = tokensOriginales.get(i + 1);
            String lcSig = sig.getLexicalComp();
            if (lcSig.equals("ENTERO")) {
                Repositorio.errores.add(new ErrorLSSL(2,
                    "Error Semántico [E9]: '!' inválido sobre valor entero — "
                    + "solo se aplica a logic (booleano) [#]", sig));
            } else if (lcSig.equals("FLOTANTE")) {
                Repositorio.errores.add(new ErrorLSSL(2,
                    "Error Semántico [E9]: '!' inválido sobre valor decimal — "
                    + "solo se aplica a logic (booleano) [#]", sig));
            } else if (lcSig.equals("CADENA")) {
                Repositorio.errores.add(new ErrorLSSL(2,
                    "Error Semántico [E9]: '!' inválido sobre cadena de texto — "
                    + "solo se aplica a logic (booleano) [#]", sig));
            } else if (lcSig.equals("CARACTER")) {
                Repositorio.errores.add(new ErrorLSSL(2,
                    "Error Semántico [E9]: '!' inválido sobre charbyte (carácter) — "
                    + "solo se aplica a logic (booleano) [#]", sig));
            } else if (lcSig.equals("IDENTIFICADOR")) {
                String id = sig.getLexeme();
                if (Repositorio.tablaSimbolos.containsKey(id)) {
                    Symbol s = Repositorio.tablaSimbolos.get(id);
                    if (!s.tipo.equals("BOOL_TYPE")) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E9]: '!' inválido sobre '"
                            + id + "' — es " + labelTipo(s.tipo)
                            + ", solo se aplica a logic (booleano) [#]",
                            tokensOriginales.get(i)));
                    }
                }
            }
        }
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // Validación de condición del for_loop
    // ════════════════════════════════════════════════════════════════════════
 
    private int validarCondicionFor(int posFor) {
        int n = tokensOriginales.size();
        int j = posFor + 1;
        while (j < n && !tokensOriginales.get(j).getLexicalComp().equals("PARENTESIS_ABRE")) j++;
        if (j >= n) return posFor;
        j++;
 
        // Saltar init hasta el primer ';'
        int depth = 1;
        while (j < n && depth > 0) {
            String lc2 = tokensOriginales.get(j).getLexicalComp();
            if (lc2.equals("PARENTESIS_ABRE"))   depth++;
            if (lc2.equals("PARENTESIS_CIERRA")) { depth--; if (depth == 0) return j; }
            if (lc2.equals("PUNTO_COMA") && depth == 1) { j++; break; }
            j++;
        }
 
        // Recolectar CONDICION hasta el segundo ';' o ')'
        ArrayList<Token> condFor = new ArrayList<>();
        while (j < n) {
            String lc2 = tokensOriginales.get(j).getLexicalComp();
            if (lc2.equals("PUNTO_COMA") || lc2.equals("PARENTESIS_CIERRA")) break;
            condFor.add(tokensOriginales.get(j));
            j++;
        }
        if (condFor.isEmpty()) return j;
 
        // [E7] Condición de un solo token no booleano
        if (condFor.size() == 1) {
            Token condTk = condFor.get(0);
            String lcCond = condTk.getLexicalComp();
            if (lcCond.equals("ENTERO") || lcCond.equals("FLOTANTE")
                    || lcCond.equals("CADENA") || lcCond.equals("CARACTER")) {
                Repositorio.errores.add(new ErrorLSSL(2,
                    "Error Semántico [E7]: Condición de 'for_loop' no es booleana "
                    + "— se encontró " + labelTipoPorLexComp(lcCond) + " [#]", condTk));
            } else if (lcCond.equals("IDENTIFICADOR")) {
                String id = condTk.getLexeme();
                if (Repositorio.tablaSimbolos.containsKey(id)) {
                    Symbol s = Repositorio.tablaSimbolos.get(id);
                    if (!s.tipo.equals("BOOL_TYPE")) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E7]: Condición de 'for_loop' no es booleana "
                            + "— '" + id + "' es " + labelTipo(s.tipo) + " [#]", condTk));
                    }
                }
            }
        }
 
        // [E5c] Comparaciones inválidas en la condición del for_loop
        for (int k = 0; k < condFor.size(); k++) {
            if (!esOperadorRelacional(condFor.get(k).getLexicalComp())) continue;
            int ki = k - 1;
            while (ki >= 0 && (condFor.get(ki).getLexicalComp().equals("PARENTESIS_CIERRA")
                    || condFor.get(ki).getLexicalComp().equals("NOT"))) ki--;
            int kd = k + 1;
            while (kd < condFor.size() && (condFor.get(kd).getLexicalComp().equals("PARENTESIS_ABRE")
                    || condFor.get(kd).getLexicalComp().equals("NOT"))) kd++;
            if (ki < 0 || kd >= condFor.size()) continue;
            String tipoIzq = inferirTipoDeToken(condFor.get(ki));
            String tipoDer = inferirTipoDeToken(condFor.get(kd));
            if (!tipoIzq.equals("UNKNOWN") && !tipoDer.equals("UNKNOWN")
                    && !sonComparables(tipoIzq, tipoDer)) {
                Repositorio.errores.add(new ErrorLSSL(2,
                    "Error Semántico [E5c]: Comparación inválida entre "
                    + labelTipo(tipoIzq) + " (" + condFor.get(ki).getLexeme() + ") y "
                    + labelTipo(tipoDer) + " (" + condFor.get(kd).getLexeme() + ")"
                    + " en condición de 'for_loop' [#]", condFor.get(k)));
            }
        }
        return j;
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // Validación de asignaciones: x = pi + 1; → detecta E4 y E5 en RHS
    // ════════════════════════════════════════════════════════════════════════
 
    /**
     * Escanea asignaciones simples (IDENT = expr ;) en tokensOriginales.
     * Detecta [E4] cuando el tipo de la expresión es incompatible con IDENT,
     * y [E5] cuando hay tipos no aritméticos en la expresión.
     * Complementa analisisSemantico que solo ve el primer token del RHS.
     */
    private void validarAsignacionesComplejas() {
        int n = tokensOriginales.size();
        HashSet<String> reportados = new HashSet<>();
 
        for (int i = 0; i < n; i++) {
            Token t  = tokensOriginales.get(i);
            String lc = t.getLexicalComp();
            if (!lc.equals("IDENTIFICADOR")) continue;
            if (i + 1 >= n) continue;
            // Debe ser: IDENT = expr (asignación, no declaración)
            if (!tokensOriginales.get(i + 1).getLexicalComp().equals("ASIGNACION")) continue;
            // Si hay TIPO_DATO inmediatamente antes → es declaración, ya manejada
            if (i > 0 && esTipoDato(tokensOriginales.get(i - 1).getLexicalComp())) continue;
            // Si hay CONST_KW dos posiciones antes → constante, ya manejada
            if (i > 1 && tokensOriginales.get(i - 2).getLexicalComp().equals("CONST_KW")) continue;
 
            String identLHS = t.getLexeme();
            if (!Repositorio.tablaSimbolos.containsKey(identLHS)) continue;
            Symbol sym = Repositorio.tablaSimbolos.get(identLHS);
 
            // Recolectar RHS
            ArrayList<Token> rhs = new ArrayList<>();
            int j = i + 2;
            int depth = 0;
            while (j < n) {
                String lc2 = tokensOriginales.get(j).getLexicalComp();
                if (lc2.equals("PARENTESIS_ABRE"))   depth++;
                if (lc2.equals("PARENTESIS_CIERRA")) depth--;
                if (depth == 0 && lc2.equals("PUNTO_COMA")) break;
                rhs.add(tokensOriginales.get(j));
                j++;
            }
            if (rhs.isEmpty()) continue;
 
            String keyE4 = "E4@" + identLHS + "@" + t.getLine();
            String keyE5 = "E5@" + identLHS + "@" + t.getLine();
 
            // [E4] Tipo de expresión incompatible con variable destino
            String tipoExpr = inferirTipoExpresion(rhs);
            if (!tipoExpr.equals("UNKNOWN") && !sonCompatibles(sym.tipo, tipoExpr)
                    && !reportados.contains(keyE4)) {
                boolean dup = false;
                for (ErrorLSSL e : Repositorio.errores)
                    if (e.getLine() == t.getLine() && e.toString().contains("[E4]")
                            && e.toString().contains(identLHS)) { dup = true; break; }
                if (!dup) {
                    Repositorio.errores.add(new ErrorLSSL(2,
                        "Error Semántico [E4]: Tipo incompatible en asignación a '"
                        + identLHS + "' (" + labelTipo(sym.tipo) + ") — la expresión "
                        + "produce " + labelTipo(tipoExpr) + " [#]", t));
                    reportados.add(keyE4);
                }
            }
 
            // [E5] Tipos inválidos en operación aritmética
            boolean tieneArit = false;
            for (Token rTk : rhs) if (esOperadorAritmeticoToken(rTk.getLexicalComp())) { tieneArit = true; break; }
            if (tieneArit && !reportados.contains(keyE5)) {
                for (Token rTk : rhs) {
                    String tipoR = inferirTipoDeToken(rTk);
                    if (tipoR.equals("CHAR_TYPE") || tipoR.equals("BOOL_TYPE")
                            || tipoR.equals("STRING_TYPE")) {
                        Repositorio.errores.add(new ErrorLSSL(2,
                            "Error Semántico [E5]: '" + rTk.getLexeme() + "' es "
                            + labelTipo(tipoR) + " y no puede usarse en operación "
                            + "aritmética en asignación a '" + identLHS + "' [#]", rTk));
                        reportados.add(keyE5);
                        break;
                    }
                }
            }
        }
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // inferirTipoExpresion — tipo dominante de una lista de tokens
    // ════════════════════════════════════════════════════════════════════════
 
    /**
     * Determina el tipo resultante de una expresión (lista de tokens).
     * Para un solo operando: devuelve su tipo directamente (neural x = pi → FLOAT).
     * Para expresiones aritméticas: promoción FLOAT > INT > BYTE.
     * Si hay BOOL/CHAR/STRING en aritmética: devuelve ese tipo (señal de error E5).
     */
    private String inferirTipoExpresion(ArrayList<Token> tokens) {
        if (tokens == null || tokens.isEmpty()) return "UNKNOWN";
 
        boolean tieneArit   = false;
        boolean tieneFloat  = false;
        boolean tieneInt    = false;
        boolean tieneBool   = false;
        boolean tieneChar   = false;
        boolean tieneString = false;
        int operandos = 0;
 
        for (Token tk : tokens) {
            String lc = tk.getLexicalComp();
            if (esOperadorAritmeticoToken(lc)) { tieneArit = true; continue; }
            if (lc.equals("PARENTESIS_ABRE") || lc.equals("PARENTESIS_CIERRA")
                    || lc.equals("NOT")) continue;
            operandos++;
            String tipo = inferirTipoDeToken(tk);
            switch (tipo) {
                case "FLOAT":       tieneFloat  = true; break;
                case "INT":
                case "BYTE_TYPE":   tieneInt    = true; break;
                case "BOOL_TYPE":   tieneBool   = true; break;
                case "CHAR_TYPE":   tieneChar   = true; break;
                case "STRING_TYPE": tieneString = true; break;
            }
        }
 
        // Un solo operando sin operador aritmético → devolver su tipo directamente
        // Clave para detectar: neural mal2 = pi; (pi es FLOAT)
        if (!tieneArit && operandos == 1) {
            if (tieneFloat)  return "FLOAT";
            if (tieneInt)    return "INT";
            if (tieneBool)   return "BOOL_TYPE";
            if (tieneChar)   return "CHAR_TYPE";
            if (tieneString) return "STRING_TYPE";
            return "UNKNOWN";
        }
 
        if (!tieneArit) return "UNKNOWN"; // múltiples operandos sin operador → complejo
 
        // Con operadores aritméticos: tipo inválido primero (para error E5)
        if (tieneChar)   return "CHAR_TYPE";
        if (tieneBool)   return "BOOL_TYPE";
        if (tieneString) return "STRING_TYPE";
        // Promoción numérica: FLOAT domina
        if (tieneFloat)  return "FLOAT";
        if (tieneInt)    return "INT";
        return "UNKNOWN";
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // Helpers de clasificación de tokens ORIGINALES
    // ════════════════════════════════════════════════════════════════════════
 
    /** Los op relacionales en tokens originales son los tokens individuales,
     *  NO "OP_REL" (ese lo crea la gramática al reducir). */
    private boolean esOperadorRelacional(String lc) {
        switch (lc) {
            case "MAYOR": case "MENOR": case "MAYOR_IGUAL":
            case "MENOR_IGUAL": case "IGUAL_IGUAL": case "DIFERENTE": return true;
            default: return false;
        }
    }
 
    /** Los op aritméticos en tokens originales son SUMA, RESTA, etc. */
    private boolean esOperadorAritmeticoToken(String lc) {
        switch (lc) {
            case "SUMA": case "RESTA": case "MULTIPLICACION":
            case "DIVISION": case "MODULO": return true;
            default: return false;
        }
    }
 
    /** Usa contieneOperadorAritmeticoToken en el exprStr reconstruido. */
    private boolean contieneOperadorAritmeticoToken(String exprStr) {
        // Los operadores aritméticos en el lexema son los símbolos reales
        return exprStr.contains("+") || exprStr.contains("-")
            || exprStr.contains("*") || exprStr.contains("/")
            || exprStr.contains("%");
    }
 
    private String labelTipoPorLexComp(String lc) {
        switch (lc) {
            case "ENTERO":   return "valor entero";
            case "FLOTANTE": return "valor decimal";
            case "CADENA":   return "cadena de texto";
            case "CARACTER": return "carácter";
            default:         return lc;
        }
    }
 
    /**
     * Infiere el tipo de un token individual:
     *   - Si es literal → usa lexCompATipo()
     *   - Si es IDENTIFICADOR → busca en la tabla de símbolos
     *   - Otros → UNKNOWN
     */
    private String inferirTipoDeToken(Token t) {
        String lc = t.getLexicalComp();
        String fromLc = lexCompATipo(lc);
        if (!fromLc.equals("UNKNOWN")) return fromLc; // es literal conocido
        if (lc.equals("IDENTIFICADOR") && Repositorio.tablaSimbolos.containsKey(t.getLexeme())) {
            return Repositorio.tablaSimbolos.get(t.getLexeme()).tipo;
        }
        return "UNKNOWN";
    }
 
    /**
     * Dos tipos son comparables (en OP_REL) si:
     *   - Son el mismo tipo, o
     *   - Ambos son numéricos (INT, FLOAT, BYTE_TYPE)
     * No se pueden comparar BOOL con numérico, STRING con numérico, etc.
     */
    private boolean sonComparables(String t1, String t2) {
        if (t1.equals(t2)) return true;
        return esNumerico(t1) && esNumerico(t2);
    }
 
    private boolean esNumerico(String tipo) {
        return tipo.equals("INT") || tipo.equals("FLOAT") || tipo.equals("BYTE_TYPE");
    }
 
 
    // ════════════════════════════════════════════════════════════════════════
    // INFERENCIA Y COMPATIBILIDAD DE TIPOS
    // ════════════════════════════════════════════════════════════════════════
 
    /**
     * Infiere el tipo de un lexema por su forma literal.
     * Retorna INT, FLOAT, BOOL_TYPE, STRING_TYPE, CHAR_TYPE, o UNKNOWN.
     */
    private String inferirTipoDeLexema(String lex) {
        if (lex == null || lex.isEmpty()) return "UNKNOWN";
        if (lex.equals("samurai") || lex.equals("punk"))     return "BOOL_TYPE";
        if (lex.startsWith("\""))                             return "STRING_TYPE";
        if (lex.startsWith("'") && lex.length() >= 3)         return "CHAR_TYPE";
        if (lex.matches("-?\\d+\\.\\d+"))                     return "FLOAT";
        if (lex.matches("-?\\d+"))                            return "INT";
        return "UNKNOWN"; // identificador o expresión compleja
    }
 
    /** Convierte el lexical component de un literal a tipo lógico. */
    private String lexCompATipo(String lc) {
        switch (lc) {
            case "ENTERO":                        return "INT";
            case "FLOTANTE":                      return "FLOAT";
            case "CADENA":                        return "STRING_TYPE";
            case "CARACTER":                      return "CHAR_TYPE";
            case "CONST_SAMURAI": case "CONST_PUNK": return "BOOL_TYPE";
            default:                              return "UNKNOWN";
        }
    }
 
    /**
     * Reglas de compatibilidad de tipos del lenguaje Cyberpunk:
     *   FLOAT    ← INT, BYTE_TYPE (promoción implícita)
     *   INT      ← BYTE_TYPE
     *   BYTE     ← INT (se acepta, puede truncar)
     *   los demás solo son compatibles consigo mismos
     */
    private boolean sonCompatibles(String tipoVar, String tipoValor) {
        if (tipoValor.equals("UNKNOWN")) return true; // no hay info suficiente
        if (tipoVar.equals(tipoValor))   return true;
        switch (tipoVar) {
            case "FLOAT":     return tipoValor.equals("INT") || tipoValor.equals("BYTE_TYPE");
            case "INT":       return tipoValor.equals("BYTE_TYPE");
            case "BYTE_TYPE": return tipoValor.equals("INT");
            default:          return false;
        }
    }
 
    // ════════════════════════════════════════════════════════════════════════
    // HELPERS
    // ════════════════════════════════════════════════════════════════════════
 
    private boolean esTipoDato(String lc) {
        switch (lc) {
            case "INT": case "FLOAT": case "STRING_TYPE":
            case "CHAR_TYPE": case "BOOL_TYPE": case "BYTE_TYPE": return true;
            default: return false;
        }
    }
 
    private boolean esLiteralToken(String lc) {
        switch (lc) {
            case "ENTERO": case "FLOTANTE": case "CADENA": case "CARACTER":
            case "CONST_SAMURAI": case "CONST_PUNK":
            case "CONST_NIGHT": case "CONST_LUCY": case "CONST_DAVID": return true;
            default: return false;
        }
    }
 
    /**
     * Verdadero si el lexema parece un nombre de usuario (no literal, no
     * palabra reservada, no operador).
     */
    private boolean pareceLexemaIdentificador(String lex) {
        if (lex == null || lex.isEmpty()) return false;
        // Un identificador de usuario SIEMPRE empieza con letra o '_'.
        // Esto excluye '(', ')', '[', ']', '{', '}', operadores, números, etc.
        if (!Character.isLetter(lex.charAt(0)) && lex.charAt(0) != '_') return false;
        if (lex.matches("-?\\d+(\\.\\d+)?")) return false;  // número
        if (lex.startsWith("\"") || lex.startsWith("'")) return false; // cadena/char
        if (lex.matches("[+\\-*/%%=<>!&|]+")) return false;   // operadores
        switch (lex) {
            case "samurai": case "punk": case "night": case "lucy": case "david":
            case "cybermain": case "start_netrun": case "end_netrun":
            case "neural": case "floatwave": case "datastring": case "charbyte":
            case "logic": case "synthbyte": case "if_net": case "net_else":
            case "for_loop": case "while_sync": case "hack_print": case "neural_scan":
            case "edgerunner": return false;
            default: return true;
        }
    }
 
    /** Verdadero si la expresión contiene algún operador aritmético. */
    private boolean contieneOperadorAritmetico(String expr) {
        return expr.contains("+") || expr.contains("-")
            || expr.contains("*") || expr.contains("/")
            || expr.contains("%");
    }
 
    private String labelTipo(String tipo) {
        switch (tipo) {
            case "INT":         return "neural (entero)";
            case "FLOAT":       return "floatwave (decimal)";
            case "STRING_TYPE": return "datastring (cadena)";
            case "CHAR_TYPE":   return "charbyte (carácter)";
            case "BOOL_TYPE":   return "logic (booleano)";
            case "BYTE_TYPE":   return "synthbyte (byte)";
            default:            return tipo;
        }
    }
 
    private Object obtenerValorDeToken(Token t) {
        try {
            switch (t.getLexicalComp()) {
                case "ENTERO":        return Integer.parseInt(t.getLexeme());
                case "FLOTANTE":      return Float.parseFloat(t.getLexeme());
                case "CADENA":        return t.getLexeme().replace("\"", "");
                case "CARACTER":      return t.getLexeme().length() > 1
                                             ? t.getLexeme().charAt(1) : t.getLexeme();
                case "CONST_SAMURAI": return "samurai (true)";
                case "CONST_PUNK":    return "punk (false)";
                case "CONST_NIGHT":   return "night";
                case "CONST_LUCY":    return "lucy";
                case "CONST_DAVID":   return "david";
                default:              return t.getLexeme();
            }
        } catch (Exception e) {
            return t.getLexeme();
        }
    }
 
    private Object intentarParsear(String expr, String tipo) {
        if (expr == null || expr.isEmpty()) return null;
        try {
            if (tipo.equals("INT") || tipo.equals("BYTE_TYPE"))
                return Integer.parseInt(expr.trim());
            if (tipo.equals("FLOAT"))
                return Float.parseFloat(expr.trim());
        } catch (NumberFormatException ignored) { }
        return expr;
    }
}