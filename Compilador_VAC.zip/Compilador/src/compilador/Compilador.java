package compilador;

public class Compilador {
    public static void main(String[] args) {
        // Configuramos el Look and Feel para que se vea moderno (opcional)
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            // Si falla, usa el defecto
        }

        // Solo lanzamos el Splash. Él se encargará de abrir el MainFrame después.
        SplashScreen splash = new SplashScreen(2000); // 2 segundos
        splash.showSplash();
    }
}