package compilador;

import compilerTools.Grammar;

public class AnalizadorSintactico {

    public void Analizar() {
        Grammar g = new Grammar(Repositorio.tokens, Repositorio.errores);

        // ═══════════════════════════════════════════════════════════════
        // FASE 1 — Eliminar errores léxicos
        // Incluye ERROR_CADENA_SIN_CERRAR (nuevo token del lexer).
        // ═══════════════════════════════════════════════════════════════
        g.delete(new String[]{
            "ERROR_LEXICO_GENERAL",
            "ERROR_ENTERO_CERO",
            "ERROR_FLOTANTE_CERO",
            "ERROR_IDENTIFICADOR",
            "ERROR_CARACTER_INVALIDO",
            "ERROR_IDENTIFICADOR_NUMERICO",
            "ERROR_CADENA_SIN_CERRAR"
        }, 1);

        // ═══════════════════════════════════════════════════════════════
        // FASE 2 — Agrupaciones atómicas
        // ═══════════════════════════════════════════════════════════════
        g.group("VALOR",
                "(ENTERO | FLOTANTE | CADENA | CARACTER | "
                + "CONST_SAMURAI | CONST_PUNK | CONST_NIGHT | "
                + "CONST_LUCY | CONST_DAVID)", true);

        g.group("TIPO_DATO",
                "(INT | FLOAT | STRING_TYPE | CHAR_TYPE | BOOL_TYPE | BYTE_TYPE)", true);

        g.group("OP_ARIT",
                "(SUMA | RESTA | MULTIPLICACION | DIVISION | MODULO)", true);

        g.group("OP_REL",
                "(MAYOR | MENOR | MAYOR_IGUAL | MENOR_IGUAL | IGUAL_IGUAL | DIFERENTE)", true);

        g.group("OP_LOG",  "(AND | OR)", true);
        g.group("OP_INC",  "(INCREMENTO | DECREMENTO)", true);
        g.group("OP_COMP",
                "(SUMA_ASIGNACION | RESTA_ASIGNACION | "
                + "MULTIPLICACION_ASIGNACION | DIVISION_ASIGNACION | MODULO_ASIGNACION)", true);

        // ═══════════════════════════════════════════════════════════════
        // FASE 3 — LOOP 1: Expresiones
        //
        // · PARENTESIS_ABRE EXPRESION PARENTESIS_CIERRA → EXPRESION:
        //   Si el paréntesis cierra correctamente, se forma EXPRESION.
        //   Si NO cierra (falta ')'), PARENTESIS_ABRE queda suelto en el
        //   stream y las reglas de error del Loop 2 lo capturan.
        //
        // · OP_INC NO se incluye aquí (preservado para ARG_FOR / sentencias).
        // ═══════════════════════════════════════════════════════════════
        g.loopForFunExecUntilChangeNotDetected(() -> {
            g.group("EXPRESION", "(IDENTIFICADOR | VALOR)");
            g.group("EXPRESION", "PARENTESIS_ABRE EXPRESION PARENTESIS_CIERRA");
            g.group("EXPRESION", "NOT EXPRESION");
            g.group("EXPRESION", "EXPRESION OP_ARIT EXPRESION");  // c/d: aritmética simple/compleja
            g.group("EXPRESION", "EXPRESION OP_REL EXPRESION");   // a/b: relacional simple/compleja
            g.group("EXPRESION", "EXPRESION OP_LOG EXPRESION");   // b: lógica compleja

            // ── Error 106 ANTES de EXPRESION EXPRESION ─────────────────
            // `neural numero 42;` → TIPO_DATO EXPRESION EXPRESION PUNTO_COMA
            // DEBE dispararse ANTES que EXPRESION EXPRESION para dar mensaje
            // correcto. SAFE: solo dispara cuando hay TIPO_DATO delante y
            // PUNTO_COMA detrás; las condiciones de if/while/for no tienen eso.
            g.group("SENTENCIA", "TIPO_DATO EXPRESION EXPRESION PUNTO_COMA",
                    true, 106,
                    "Error Sint\u00e1ctico: Falta '=' en la declaraci\u00f3n [#]");

            // ── Operador lógico incompleto ('|' o '&' solo) ────────────
            // '|' / '&' solos → ERROR_LEXICO_GENERAL → borrados en Fase 1
            // → dos EXPRESION consecutivas dentro de condición.
            // Se absorben aquí para que if/while/for sigan reduciendo.
            // SAFE: TIPO_DATO EXPRESION EXPRESION ya fue capturado arriba.
            g.group("EXPRESION", "EXPRESION EXPRESION",
                    true, 5,
                    "Error Sint\u00e1ctico: Operador l\u00f3gico incompleto "
                    + "— \u00bfuso '|' en lugar de '||' o '&' en lugar de '&&'? [#]");
        });

        // ═══════════════════════════════════════════════════════════════
        // FASE 4 — LOOP 2: Sentencias
        // ═══════════════════════════════════════════════════════════════
        g.loopForFunExecUntilChangeNotDetected(() -> {

            // ── 1. ARG_FOR — SIEMPRE PRIMERO ─────────────────────────
            // Antes de declaraciones para proteger "neural i = 0;".
            // El paso usa EXPRESION OP_INC porque i++ sigue como tal.
            //
            // ── 1b. DECL_PARTIAL — Declaraciones múltiples ────────────
            // Antes de las reglas de declaración simple para que
            // "neural x, y;" no sea consumido parcialmente.
            //
            // Estrategia: DECL_PARTIAL absorbe de izquierda a derecha
            // incluyendo la COMA final. Así cada ítem es atómico:
            //   "neural x,"          → TIPO_DATO EXPRESION COMA
            //   "neural x = 5,"      → TIPO_DATO EXPRESION ASIGNACION EXPRESION COMA
            //   "DECL_PARTIAL y,"    → DECL_PARTIAL EXPRESION COMA
            //   "DECL_PARTIAL y=5,"  → DECL_PARTIAL EXPRESION ASIGNACION EXPRESION COMA
            // Cierre con PUNTO_COMA:
            //   "DECL_PARTIAL z;"    → SENTENCIA
            //   "DECL_PARTIAL z=5;"  → SENTENCIA
            //
            // NO interfiere con ARG_FOR (el init del for termina con PUNTO_COMA,
            // no con COMA).
            // NO interfiere con asignaciones (empiezan con EXPRESION, no TIPO_DATO).
            // NO interfiere con declaraciones simples (terminan con PUNTO_COMA directo).
            g.group("DECL_PARTIAL", "TIPO_DATO EXPRESION ASIGNACION EXPRESION COMA", true);
            g.group("DECL_PARTIAL", "TIPO_DATO EXPRESION COMA", true);
            g.group("DECL_PARTIAL", "DECL_PARTIAL EXPRESION ASIGNACION EXPRESION COMA", true);
            g.group("DECL_PARTIAL", "DECL_PARTIAL EXPRESION COMA", true);
            // Cierre: último elemento (con o sin valor)
            g.group("SENTENCIA", "DECL_PARTIAL EXPRESION ASIGNACION EXPRESION PUNTO_COMA",
                    true, Repositorio.declaraciones);
            g.group("SENTENCIA", "DECL_PARTIAL EXPRESION PUNTO_COMA",
                    true, Repositorio.declaraciones);
            // Error: falta ';' al cerrar
            g.group("SENTENCIA", "DECL_PARTIAL EXPRESION ASIGNACION EXPRESION",
                    true, 9, "Error Sintáctico: Falta ';' en declaración múltiple [#]");
            g.group("SENTENCIA", "DECL_PARTIAL EXPRESION",
                    true, 9, "Error Sintáctico: Falta ';' en declaración múltiple [#]");

            g.group("ARG_FOR",
                    "(TIPO_DATO EXPRESION ASIGNACION EXPRESION "
                    + "| EXPRESION ASIGNACION EXPRESION) "
                    + "PUNTO_COMA EXPRESION PUNTO_COMA "
                    + "(EXPRESION OP_INC | OP_INC EXPRESION)", true);

            // ── 2. PRINT / SCAN correctos ─────────────────────────────
            // Los paréntesis ya fueron consumidos a EXPRESION en Loop 1
            // cuando estaban correctamente cerrados.
            // hack_print("mensaje");
            g.group("SENTENCIA",
                    "PRINT EXPRESION PUNTO_COMA",
                    true, Repositorio.funciones);
            // neural_scan(variable);
            g.group("SENTENCIA",
                    "SCAN EXPRESION PUNTO_COMA",
                    true, Repositorio.funciones);

            // ── 3. Constantes y declaraciones (CONST_KW PRIMERO) ─────────────────
            // CRITICO: CONST_KW antes de TIPO_DATO. La libreria escanea izq->der
            // y si TIPO_DATO va primero, en el stream "CONST_KW TIPO_DATO EXPR = EXPR ;"
            // encuentra "TIPO_DATO EXPR = EXPR ;" en posicion 1 y lo reduce a
            // SENTENCIA, dejando CONST_KW suelto e irreducible dentro del bloque.
            //
            // ── 3a. Constante simple: edgerunner neural MAX = 100; ────
            g.group("SENTENCIA",
                    "CONST_KW TIPO_DATO EXPRESION ASIGNACION EXPRESION PUNTO_COMA",
                    true, Repositorio.constantes);
            // ── 3b. Constantes multiples: edgerunner neural MAX=100, MIN=0; ──
            g.group("CONST_PARTIAL", "CONST_KW TIPO_DATO EXPRESION ASIGNACION EXPRESION COMA", true);
            g.group("CONST_PARTIAL", "CONST_PARTIAL EXPRESION ASIGNACION EXPRESION COMA", true);
            g.group("SENTENCIA", "CONST_PARTIAL EXPRESION ASIGNACION EXPRESION PUNTO_COMA",
                    true, Repositorio.constantes);
            // ── 3c. Variables simples ─────────────────────────────────
            g.group("SENTENCIA",
                    "TIPO_DATO EXPRESION ASIGNACION EXPRESION PUNTO_COMA",
                    true, Repositorio.declaraciones);
            g.group("SENTENCIA",
                    "TIPO_DATO EXPRESION PUNTO_COMA",
                    true, Repositorio.declaraciones);
            g.group("SENTENCIA",
                    "EXPRESION ASIGNACION EXPRESION PUNTO_COMA",
                    true, Repositorio.asignaciones);
            g.group("SENTENCIA",
                    "EXPRESION OP_COMP EXPRESION PUNTO_COMA",
                    true, Repositorio.asignaciones);
            g.group("SENTENCIA",
                    "EXPRESION OP_INC PUNTO_COMA",       // x++;  x--;
                    true, Repositorio.asignaciones);
            g.group("SENTENCIA",
                    "OP_INC EXPRESION PUNTO_COMA",       // ++x;  --x;
                    true, Repositorio.asignaciones);

            // ── 4. Bloque de código ───────────────────────────────────
            g.group("BLOQUE_CODIGO", "START_BLOCK (SENTENCIA)* END_BLOCK", true);

            // ── 5. Estructuras de control correctas ───────────────────
            // CON-ELSE antes de SIN-ELSE.
            // IF y WHILE usan EXPRESION (paréntesis ya consumidos).
            // FOR conserva sus paréntesis (interior tenía PUNTO_COMA).
            g.group("SENTENCIA",
                    "IF EXPRESION BLOQUE_CODIGO ELSE BLOQUE_CODIGO", true);
            g.group("SENTENCIA",
                    "IF EXPRESION BLOQUE_CODIGO", true);
            g.group("SENTENCIA",
                    "WHILE EXPRESION BLOQUE_CODIGO", true);
            g.group("SENTENCIA",
                    "FOR PARENTESIS_ABRE ARG_FOR PARENTESIS_CIERRA BLOQUE_CODIGO", true);

            // ── 5b. BLOQUE_CODIGO segunda pasada ─────────────────────────
            // Después de que IF/WHILE/FOR se redujeron a SENTENCIA (paso 5),
            // el bloque contenedor ya tiene TODO su contenido como SENTENCIA.
            // Esta segunda llamada permite cerrarlo en el MISMO pase.
            g.group("BLOQUE_CODIGO", "START_BLOCK (SENTENCIA)* END_BLOCK", true);

            // ── 5c. Typo en start_netrun ────────────────────────────────
            // 'start_netru' → IDENTIFICADOR → EXPRESION (sin START_BLOCK).
            // SAFE: en código válido hay START_BLOCK → BLOQUE_CODIGO antes
            // del SENTENCIA*, así que este patrón no dispara para código ok.
            g.group("BLOQUE_CODIGO", "EXPRESION (SENTENCIA)* END_BLOCK",
                    true, 61,
                    "Error Sint\u00e1ctico: Se esperaba 'start_netrun' para abrir el bloque [#]");

            // ════════════════════════════════════════════════════════════
            // REGLAS DE ERROR — siempre al final del loop
            // ════════════════════════════════════════════════════════════

            // ─────────────────────────────────────────────────────────────
            // ORDEN CRÍTICO DE ERRORES — más específico SIEMPRE antes que
            // más general. La librería escanea izq→der; si TIPO_DATO EXPRESION
            // (error 11) va antes, consume el inicio de patrones más largos y
            // deja ASIGNACION / PUNTO_COMA sueltos → cascada de end_netrun.
            // ─────────────────────────────────────────────────────────────

            // ── Primero: valor vacío después de '='  ─────────────────────
            // (6 tokens / 5 tokens → más largo que error 12/10/11)
            g.group("SENTENCIA",
                    "CONST_KW TIPO_DATO EXPRESION ASIGNACION PUNTO_COMA",
                    true, 100,
                    "Error Sint\u00e1ctico: La constante no tiene valor despu\u00e9s de '=' [#]");
            g.group("SENTENCIA",
                    "TIPO_DATO EXPRESION ASIGNACION PUNTO_COMA",
                    true, 101,
                    "Error Sint\u00e1ctico: Falta el valor despu\u00e9s de '=' en la declaraci\u00f3n [#]");
            g.group("SENTENCIA",
                    "EXPRESION ASIGNACION PUNTO_COMA",
                    true, 102,
                    "Error Sint\u00e1ctico: Falta el valor despu\u00e9s de '=' en la asignaci\u00f3n [#]");

            // ── Segundo: falta nombre de variable/constante ───────────────
            g.group("SENTENCIA",
                    "CONST_KW TIPO_DATO PUNTO_COMA",
                    true, 103,
                    "Error Sint\u00e1ctico: Falta el nombre de la constante [#]");
            g.group("SENTENCIA",
                    "TIPO_DATO PUNTO_COMA",
                    true, 104,
                    "Error Sint\u00e1ctico: Falta el nombre de la variable [#]");
            // neural = 5;  → TIPO_DATO ASIGNACION EXPRESION PUNTO_COMA
            g.group("SENTENCIA",
                    "TIPO_DATO ASIGNACION EXPRESION PUNTO_COMA",
                    true, 105,
                    "Error Sint\u00e1ctico: Falta el nombre de la variable "
                    + "(\u00bfolvid\u00f3 escribirlo antes de '='?) [#]");

            // ── Tercero: falta ';' (con expresión presente) ───────────────
            // CONST_KW primero (razón de orden ya conocida).
            g.group("SENTENCIA",
                    "CONST_KW TIPO_DATO EXPRESION ASIGNACION EXPRESION",
                    true, 12,
                    "Error Sint\u00e1ctico: Falta ';' al final de la constante [#]");
            g.group("SENTENCIA", "CONST_PARTIAL EXPRESION ASIGNACION EXPRESION",
                    true, 8, "Error Sint\u00e1ctico: Falta ';' en declaraci\u00f3n m\u00faltiple de constantes [#]");
            g.group("SENTENCIA", "CONST_PARTIAL EXPRESION PUNTO_COMA",
                    true, 8, "Error Sint\u00e1ctico: Las constantes deben inicializarse con '=' [#]");
            g.group("SENTENCIA",
                    "TIPO_DATO EXPRESION ASIGNACION EXPRESION",
                    true, 10,
                    "Error Sint\u00e1ctico: Falta ';' al final de la declaraci\u00f3n [#]");
            // error 11 va AL FINAL porque TIPO_DATO EXPRESION es el patrón
            // más corto; si fuera antes tragaría el inicio de patrones largos.
            g.group("SENTENCIA",
                    "TIPO_DATO EXPRESION",
                    true, 11,
                    "Error Sint\u00e1ctico: Falta ';' al final de la declaraci\u00f3n [#]");
            g.group("SENTENCIA",
                    "EXPRESION ASIGNACION EXPRESION",
                    true, 13,
                    "Error Sintáctico: Falta ';' al final de la asignación [#]");
            g.group("SENTENCIA",
                    "EXPRESION OP_INC",
                    true, 14,
                    "Error Sintáctico: Falta ';' después de incremento/decremento [#]");
            g.group("SENTENCIA",
                    "OP_INC EXPRESION",
                    true, 15,
                    "Error Sintáctico: Falta ';' después de incremento/decremento [#]");
            g.group("SENTENCIA",
                    "EXPRESION OP_COMP EXPRESION",
                    true, 16,
                    "Error Sintáctico: Falta ';' en asignación compuesta [#]");

            // ── Typo en palabra reservada (ej: 'ifnet' en vez de 'if_net') ──
            // SAFE: requiere DOS EXPRESSIONes antes del bloque.
            // IF/WHILE/FOR válidos tienen exactamente UNA → nunca disparan aquí.
            g.group("SENTENCIA",
                    "EXPRESION EXPRESION BLOQUE_CODIGO ELSE BLOQUE_CODIGO",
                    true, 35,
                    "Error Sint\u00e1ctico: Palabra reservada no reconocida "
                    + "— \u00bfquiso 'if_net (cond) ... net_else'? [#]");
            g.group("SENTENCIA",
                    "EXPRESION EXPRESION BLOQUE_CODIGO",
                    true, 36,
                    "Error Sint\u00e1ctico: Palabra reservada no reconocida antes del bloque [#]");

            // ── Falta ';' en PRINT / SCAN (paréntesis bien cerrados) ──
            g.group("SENTENCIA",
                    "PRINT EXPRESION",
                    true, 20,
                    "Error Sintáctico: Falta ';' al final de hack_print [#]");
            g.group("SENTENCIA",
                    "SCAN EXPRESION",
                    true, 21,
                    "Error Sintáctico: Falta ';' al final de neural_scan [#]");

            // ── Falta ')' en PRINT ─────────────────────────────────────
            // Cuando el '(' está pero falta ')': el Loop 1 no pudo consumir
            // el PARENTESIS_ABRE → queda suelto en el stream.
            // hack_print("texto";   → PRINT PARENTESIS_ABRE EXPRESION PUNTO_COMA
            g.group("SENTENCIA",
                    "PRINT PARENTESIS_ABRE EXPRESION PUNTO_COMA",
                    true, 22,
                    "Error Sintáctico: Falta ')' para cerrar hack_print [#]");
            // hack_print("texto"    → sin ')' y sin ';'
            g.group("SENTENCIA",
                    "PRINT PARENTESIS_ABRE EXPRESION",
                    true, 22,
                    "Error Sintáctico: Faltan ')' y ';' para cerrar hack_print [#]");

            // ── Falta ')' en SCAN ─────────────────────────────────────
            // neural_scan(x;        → SCAN PARENTESIS_ABRE EXPRESION PUNTO_COMA
            g.group("SENTENCIA",
                    "SCAN PARENTESIS_ABRE EXPRESION PUNTO_COMA",
                    true, 23,
                    "Error Sintáctico: Falta ')' para cerrar neural_scan [#]");
            g.group("SENTENCIA",
                    "SCAN PARENTESIS_ABRE EXPRESION",
                    true, 23,
                    "Error Sintáctico: Faltan ')' y ';' para cerrar neural_scan [#]");

            // ── Errores en if_net ──────────────────────────────────────
            g.group("SENTENCIA",
                    "IF BLOQUE_CODIGO ELSE BLOQUE_CODIGO",
                    true, 30,
                    "Error Sintáctico: Falta la condición en if_net [#]");
            g.group("SENTENCIA",
                    "IF BLOQUE_CODIGO",
                    true, 31,
                    "Error Sintáctico: Falta la condición en if_net [#]");
            // Falta ')' en condición de if_net
            g.group("SENTENCIA",
                    "IF PARENTESIS_ABRE EXPRESION BLOQUE_CODIGO ELSE BLOQUE_CODIGO",
                    true, 32,
                    "Error Sintáctico: Falta ')' para cerrar la condición de if_net [#]");
            g.group("SENTENCIA",
                    "IF PARENTESIS_ABRE EXPRESION BLOQUE_CODIGO",
                    true, 32,
                    "Error Sintáctico: Falta ')' para cerrar la condición de if_net [#]");
            g.group("SENTENCIA",
                    "IF EXPRESION SENTENCIA",
                    true, 33,
                    "Error Sintáctico: Se esperaba 'start_netrun' para el bloque de if_net [#]");
            g.group("SENTENCIA",
                    "IF PARENTESIS_ABRE PARENTESIS_CIERRA BLOQUE_CODIGO",
                    true, 34,
                    "Error Sintáctico: La condición de if_net está vacía [#]");

            // ── Errores en while_sync ──────────────────────────────────
            g.group("SENTENCIA",
                    "WHILE BLOQUE_CODIGO",
                    true, 40,
                    "Error Sintáctico: Falta la condición en while_sync [#]");
            // Falta ')' en condición de while_sync
            g.group("SENTENCIA",
                    "WHILE PARENTESIS_ABRE EXPRESION BLOQUE_CODIGO",
                    true, 41,
                    "Error Sintáctico: Falta ')' para cerrar la condición de while_sync [#]");
            g.group("SENTENCIA",
                    "WHILE EXPRESION SENTENCIA",
                    true, 42,
                    "Error Sintáctico: Se esperaba 'start_netrun' para el bloque de while_sync [#]");
            g.group("SENTENCIA",
                    "WHILE PARENTESIS_ABRE PARENTESIS_CIERRA BLOQUE_CODIGO",
                    true, 43,
                    "Error Sintáctico: La condición de while_sync está vacía [#]");

            // ── Errores en for_loop ────────────────────────────────────
            g.group("SENTENCIA",
                    "FOR PARENTESIS_ABRE ARG_FOR BLOQUE_CODIGO",
                    true, 50,
                    "Error Sintáctico: Falta ')' para cerrar for_loop [#]");
            g.group("SENTENCIA",
                    "FOR ARG_FOR PARENTESIS_CIERRA BLOQUE_CODIGO",
                    true, 51,
                    "Error Sintáctico: Falta '(' para abrir for_loop [#]");
            g.group("SENTENCIA",
                    "FOR PARENTESIS_ABRE PARENTESIS_CIERRA BLOQUE_CODIGO",
                    true, 52,
                    "Error Sintáctico: Los parámetros de for_loop están vacíos [#]");
            g.group("SENTENCIA",
                    "FOR BLOQUE_CODIGO",
                    true, 53,
                    "Error Sintáctico: Faltan los parámetros '(init; cond; paso)' en for_loop [#]");

            // ── Errores de constante ───────────────────────────────────
            g.group("SENTENCIA",
                    "CONST_KW EXPRESION ASIGNACION EXPRESION PUNTO_COMA",
                    true, 70,
                    "Error Sintáctico: Se esperaba un tipo de dato después de 'const' [#]");
            g.group("SENTENCIA",
                    "CONST_KW TIPO_DATO EXPRESION PUNTO_COMA",
                    true, 71,
                    "Error Sintáctico: La constante debe inicializarse con '=' valor [#]");
        });

        // ═══════════════════════════════════════════════════════════════
        // POST-LOOP
        // ═══════════════════════════════════════════════════════════════

        // Post-loop: último intento de cierre correcto antes de disparar el error.
        g.group("BLOQUE_CODIGO", "START_BLOCK (SENTENCIA)* END_BLOCK", true);

        // Bloque sin 'end_netrun' — solo dispara si no cerró arriba.
        g.group("BLOQUE_CODIGO",
                "START_BLOCK (SENTENCIA)*",
                true, 60,
                "Error Sintáctico: Falta 'end_netrun' para cerrar el bloque [#]");

        // Programa principal
        g.group("PROGRAMA", "(SENTENCIA)+ MAIN BLOQUE_CODIGO",
                true, 93,
                "Error Sint\u00e1ctico: No se permite c\u00f3digo antes de 'cybermain' [#]");
        g.group("PROGRAMA", "MAIN BLOQUE_CODIGO", true);
        g.group("PROGRAMA",
                "MAIN START_BLOCK (SENTENCIA)*",
                true, 90,
                "Error Fatal: Falta 'end_netrun' al final del programa [#]");
        g.group("PROGRAMA",
                "MAIN (SENTENCIA)+",
                true, 91,
                "Error Sintáctico: Se esperaba 'start_netrun' después de cybermain [#]");
        g.group("PROGRAMA",
                "BLOQUE_CODIGO",
                true, 92,
                "Error Sintáctico: Se esperaba 'cybermain' al inicio del programa [#]");
        g.show();
    }
}