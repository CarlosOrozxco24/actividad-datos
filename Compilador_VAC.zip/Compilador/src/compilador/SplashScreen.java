package compilador;

import javax.swing.*;
import java.awt.*;

public class SplashScreen {
    private final int duration;

    public SplashScreen(int durationMillis) {
        this.duration = durationMillis;
    }

    public void showSplash() {
        JWindow window = new JWindow();

        // Panel principal con fondo azul marino
        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(new Color(10, 25, 47)); // azul marino
        content.setBorder(BorderFactory.createLineBorder(new Color(0, 120, 215), 4, true)); 
        // borde azul claro, redondeado

        // Imagen (opcional)
        JLabel imageLabel;
        ImageIcon icon = null;
        try {
            // Intenta cargar la imagen, si no existe usa texto
            java.net.URL imgURL = getClass().getResource("/icons/splash.png");
            if (imgURL != null) {
                icon = new ImageIcon(imgURL);
                Image img = icon.getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH);
                icon = new ImageIcon(img);
                imageLabel = new JLabel(icon, SwingConstants.CENTER);
            } else {
                throw new Exception("Imagen no encontrada");
            }
        } catch (Exception e) {
            // Placeholder si falla la imagen
            imageLabel = new JLabel("<html><center><h1 style='color:white'>PunkSystem</h1><p style='color:gray'>Compilador v1.0</p></center></html>", SwingConstants.CENTER);
        }

        content.add(imageLabel, BorderLayout.CENTER);

        // Texto del desarrollador
        JLabel developer = new JLabel("Desarrolladores: Juan Medina & Carlos Montelongo", SwingConstants.CENTER);
        developer.setForeground(Color.WHITE); 
        developer.setFont(new Font("SansSerif", Font.PLAIN, 14));
        developer.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        content.add(developer, BorderLayout.SOUTH);

        // Configuración ventana
        window.setContentPane(content);
        window.setSize(500, 350);
        window.setLocationRelativeTo(null);
        window.setVisible(true);

        // Timer para cerrar el splash y abrir MainFrame
        Timer timer = new Timer(duration, ae -> {
            window.setVisible(false);
            window.dispose();
            // Abrimos la ventana principal aquí
            java.awt.EventQueue.invokeLater(() -> {
                new MainFrame().setVisible(true);
            });
        });
        timer.setRepeats(false);
        timer.start();
    }
}