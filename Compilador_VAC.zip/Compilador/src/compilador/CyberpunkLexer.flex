package compilador;

import compilerTools.Token;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

%%
%class CyberpunkLexer
%type Token
%line
%ignorecase
%column

%init{
    // Constructor section
%init}

%{
  private Token token(String lexema, String componenteLexico, int line, int column)
   {
    return new Token(lexema, componenteLexico, line+1, column+1);
   }
%}

// Line terminator
TerminadorLinea = \r|\n|\r\n
Espacio     = {TerminadorLinea} | [ \t\f]

Entero = [0-9]+
Flotante = {Entero}"."{Entero}
UnCaracter = [^\r\n]

// CaracterSinComillas excluye salto de línea y comilla recta.
// CRÍTICO: evita que una cadena sin cerrar consuma el resto del archivo.
CaracterSinComillas = [^\"\r\n]

ContenidoComentario  = ( [^*] | \*+ [^/*] )*
ComentarioDocumentar = "/**" {ContenidoComentario} "*"+ "/"
ComentarioBloque   = "/*" [^*] ~"*/" | {ComentarioDocumentar}
ComentarioLinea    = "//" {UnCaracter}* {TerminadorLinea}?
Comentario = {ComentarioBloque} | {ComentarioLinea} | {ComentarioDocumentar}

// Letra base con soporte para caracteres acentuados (á,é,í,ó,ú,ñ,Á,É,etc.)
LetraBase = [a-zA-Z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u024F]
Identificador = [_]?{LetraBase}({LetraBase}|[0-9_])*

Cadena = "\""{CaracterSinComillas}*"\""
Caracter = "'"{UnCaracter}{1}"'"

// Cadena sin cerrar: empieza con " pero no termina en la misma línea.
// Se detecta como error léxico para no consumir end_netrun u otros tokens.
CadenaSinCerrar = "\""{CaracterSinComillas}*

// Caracteres inválidos para identificar errores léxicos
CaracterInvalido = [@#$%&\?|\\`~]

%%

// IMPORTANTE: El orden de las reglas es CRÍTICO

// 1. Palabras reservadas individuales (cada una con su token específico)
"cybermain"    {return token(yytext(),"MAIN",yyline,yycolumn);}
"start_netrun" {return token(yytext(),"START_BLOCK",yyline,yycolumn);}
"end_netrun"   {return token(yytext(),"END_BLOCK",yyline,yycolumn);}
"neural"       {return token(yytext(),"INT",yyline,yycolumn);}
"floatwave"    {return token(yytext(),"FLOAT",yyline,yycolumn);}
"datastring"   {return token(yytext(),"STRING_TYPE",yyline,yycolumn);}
"charbyte"     {return token(yytext(),"CHAR_TYPE",yyline,yycolumn);}
"logic"        {return token(yytext(),"BOOL_TYPE",yyline,yycolumn);}
"synthbyte"    {return token(yytext(),"BYTE_TYPE",yyline,yycolumn);}
"if_net"       {return token(yytext(),"IF",yyline,yycolumn);}
"net_else"     {return token(yytext(),"ELSE",yyline,yycolumn);}
"switch_grid"  {return token(yytext(),"SWITCH",yyline,yycolumn);}
"for_loop"     {return token(yytext(),"FOR",yyline,yycolumn);}
"do_netrun"    {return token(yytext(),"DO",yyline,yycolumn);}
"while_sync"   {return token(yytext(),"WHILE",yyline,yycolumn);}
"repeat_until" {return token(yytext(),"REPEAT",yyline,yycolumn);}
"hack_print"   {return token(yytext(),"PRINT",yyline,yycolumn);}
"neural_scan"  {return token(yytext(),"SCAN",yyline,yycolumn);}
// "const" eliminado — usar "edgerunner" para declarar constantes

// Constantes predefinidas
"samurai"      {return token(yytext(),"CONST_SAMURAI",yyline,yycolumn);}
"punk"         {return token(yytext(),"CONST_PUNK",yyline,yycolumn);}
"night"        {return token(yytext(),"CONST_NIGHT",yyline,yycolumn);}
"edgerunner"   {return token(yytext(),"CONST_KW",yyline,yycolumn);}
"lucy"         {return token(yytext(),"CONST_LUCY",yyline,yycolumn);}
"david"        {return token(yytext(),"CONST_DAVID",yyline,yycolumn);}

// 2. Operadores aritméticos individuales (orden importante: ++ antes de +)
"++" {return token(yytext(),"INCREMENTO",yyline,yycolumn);}
"--" {return token(yytext(),"DECREMENTO",yyline,yycolumn);}
"+=" {return token(yytext(),"SUMA_ASIGNACION",yyline,yycolumn);}
"-=" {return token(yytext(),"RESTA_ASIGNACION",yyline,yycolumn);}
"*=" {return token(yytext(),"MULTIPLICACION_ASIGNACION",yyline,yycolumn);}
"/=" {return token(yytext(),"DIVISION_ASIGNACION",yyline,yycolumn);}
"%=" {return token(yytext(),"MODULO_ASIGNACION",yyline,yycolumn);}
"+" {return token(yytext(),"SUMA",yyline,yycolumn);}
"-" {return token(yytext(),"RESTA",yyline,yycolumn);}
"*" {return token(yytext(),"MULTIPLICACION",yyline,yycolumn);}
"/" {return token(yytext(),"DIVISION",yyline,yycolumn);}
"%" {return token(yytext(),"MODULO",yyline,yycolumn);}

// 3. Operadores relacionales individuales (orden importante: == antes de =)
">=" {return token(yytext(),"MAYOR_IGUAL",yyline,yycolumn);}
"<=" {return token(yytext(),"MENOR_IGUAL",yyline,yycolumn);}
"==" {return token(yytext(),"IGUAL_IGUAL",yyline,yycolumn);}
"!=" {return token(yytext(),"DIFERENTE",yyline,yycolumn);}
">" {return token(yytext(),"MAYOR",yyline,yycolumn);}
"<" {return token(yytext(),"MENOR",yyline,yycolumn);}

// 4. Operadores lógicos individuales
"&&" {return token(yytext(),"AND",yyline,yycolumn);}
"||" {return token(yytext(),"OR",yyline,yycolumn);}
"!" {return token(yytext(),"NOT",yyline,yycolumn);}

// 5. Operadores de asignación
"=" {return token(yytext(),"ASIGNACION",yyline,yycolumn);}

// 6. Signos de puntuación individuales
";" {return token(yytext(),"PUNTO_COMA",yyline,yycolumn);}
"," {return token(yytext(),"COMA",yyline,yycolumn);}
"(" {return token(yytext(),"PARENTESIS_ABRE",yyline,yycolumn);}
")" {return token(yytext(),"PARENTESIS_CIERRA",yyline,yycolumn);}
"{" {return token(yytext(),"LLAVE_ABRE",yyline,yycolumn);}
"}" {return token(yytext(),"LLAVE_CIERRA",yyline,yycolumn);}
"[" {return token(yytext(),"CORCHETE_ABRE",yyline,yycolumn);}
"]" {return token(yytext(),"CORCHETE_CIERRA",yyline,yycolumn);}
"." {return token(yytext(),"PUNTO",yyline,yycolumn);}
":" {return token(yytext(),"DOS_PUNTOS",yyline,yycolumn);}

// 7. Errores léxicos ESPECÍFICOS - deben ir ANTES de los tokens válidos
"0"{Entero}         {return token(yytext(),"ERROR_ENTERO_CERO",yyline,yycolumn);}
"0"{Flotante}       {return token(yytext(),"ERROR_FLOTANTE_CERO",yyline,yycolumn);}
"_"{Identificador}  {return token(yytext(),"ERROR_IDENTIFICADOR",yyline,yycolumn);}
{CaracterInvalido}  {return token(yytext(),"ERROR_CARACTER_INVALIDO",yyline,yycolumn);}
[0-9]+{Identificador} {return token(yytext(),"ERROR_IDENTIFICADOR_NUMERICO",yyline,yycolumn);}

// 8. Tokens básicos VÁLIDOS
// IMPORTANTE: {Cadena} DEBE ir antes de {CadenaSinCerrar} — JFlex usa la
// regla más larga primero, así que una cadena cerrada correctamente
// se reconoce como CADENA antes de que CadenaSinCerrar haga match.
{Cadena}          {return token(yytext(),"CADENA",yyline,yycolumn);}
{CadenaSinCerrar} {return token(yytext(),"ERROR_CADENA_SIN_CERRAR",yyline,yycolumn);}
{Caracter}        {return token(yytext(),"CARACTER",yyline,yycolumn);}
{Flotante}        {return token(yytext(),"FLOTANTE",yyline,yycolumn);}
{Entero}          {return token(yytext(),"ENTERO",yyline,yycolumn);}      
{Identificador}   {return token(yytext(),"IDENTIFICADOR",yyline,yycolumn);}

// 9. Comentarios y espacios (ignorar)
{ComentarioLinea} {/* Ignorar */}
{Comentario}      {/* Ignorar */}
{Espacio}         {/* Ignorar */}

// 10. Cualquier otro carácter no reconocido - DEBE IR AL FINAL
. {return token(yytext(),"ERROR_LEXICO_GENERAL",yyline,yycolumn);}
