package compilador;

import java.awt.Color;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.JTextPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class SyntaxHighlighter {

    private static final ClassArchivoPropiedades prop = new ClassArchivoPropiedades();

    private static Color parseColor(String hex, Color fallback) {
        try {
            if (hex == null) return fallback;
            return Color.decode(hex);
        } catch (Exception e) {
            return fallback;
        }
    }

    private static SimpleAttributeSet attr(Color c) {
        SimpleAttributeSet a = new SimpleAttributeSet();
        StyleConstants.setForeground(a, c);
        // Aseguramos que no sea negrita ni cursiva por defecto, solo color
        StyleConstants.setBold(a, false);
        StyleConstants.setItalic(a, false);
        return a;
    }

    // Patrones Regex (Ajustados para tu lenguaje del PDF)
    private static final Pattern COMMENT = Pattern.compile("(?s)/\\*.*?\\*/|//.*"); // Comentarios /* */ y //
    private static final Pattern STRING = Pattern.compile("\"(\\\\.|[^\\\\\"])*\"");
    private static final Pattern FLOAT = Pattern.compile("\\b\\d+\\.\\d+\\b");
    private static final Pattern INTEGER = Pattern.compile("\\b\\d+\\b");

    public static void highlight(final JTextPane pane) {
        if (pane == null) return;
        SwingUtilities.invokeLater(() -> {
            try {
                StyledDocument doc = pane.getStyledDocument();
                String text = doc.getText(0, doc.getLength());

                // Leer colores de propiedades
                Color general = parseColor(prop.LeerPropiedades("color.general"), Color.BLACK);
                Color reserved = parseColor(prop.LeerPropiedades("color.reserved"), Color.BLUE);
                Color comments = parseColor(prop.LeerPropiedades("color.comments"), new Color(0, 128, 0));
                Color strings = parseColor(prop.LeerPropiedades("color.strings"), Color.RED);
                Color identifiers = parseColor(prop.LeerPropiedades("color.identifiers"), Color.BLACK);
                Color integer = parseColor(prop.LeerPropiedades("color.integer"), new Color(0, 0, 128));
                Color flt = parseColor(prop.LeerPropiedades("color.float"), new Color(0, 0, 128));
                Color punct = parseColor(prop.LeerPropiedades("color.punctuation"), Color.DARK_GRAY);

                SimpleAttributeSet genAttr = attr(general);
                SimpleAttributeSet resAttr = attr(reserved);
                SimpleAttributeSet comAttr = attr(comments);
                SimpleAttributeSet strAttr = attr(strings);
                SimpleAttributeSet intAttr = attr(integer);
                SimpleAttributeSet floatAttr = attr(flt);
                SimpleAttributeSet punctAttr = attr(punct);

                // Resetear todo al color general
                doc.setCharacterAttributes(0, text.length(), genAttr, true);

                // 1. Comentarios
                Matcher m = COMMENT.matcher(text);
                while (m.find()) doc.setCharacterAttributes(m.start(), m.end() - m.start(), comAttr, false);

                // 2. Cadenas
                m = STRING.matcher(text);
                while (m.find()) doc.setCharacterAttributes(m.start(), m.end() - m.start(), strAttr, false);

                // 3. Números (Flotantes y Enteros)
                m = FLOAT.matcher(text);
                while (m.find()) doc.setCharacterAttributes(m.start(), m.end() - m.start(), floatAttr, false);
                
                m = INTEGER.matcher(text);
                while (m.find()) {
                     // Lógica simple para evitar colorear partes de flotantes como enteros
                     doc.setCharacterAttributes(m.start(), m.end() - m.start(), intAttr, false);
                }

                // 4. Palabras Reservadas (Definidas en tu Flex)
                // Lista basada en tu CyberpunkLexer.flex
                String[] words = {
                    "cybermain", "start_netrun", "end_netrun", "neural", "floatwave", 
                    "datastring", "charbyte", "logic", "synthbyte", "if_net", "net_else", 
                    "switch_grid", "for_loop", "do_netrun", "while_sync", "repeat_until", 
                    "hack_print", "neural_scan", "samurai", "punk", "night", "edgerunner"
                };
                
                StringBuilder sb = new StringBuilder();
                for (String w : words) {
                    if (sb.length() > 0) sb.append("|");
                    sb.append("\\b").append(Pattern.quote(w)).append("\\b");
                }
                Pattern reservedPattern = Pattern.compile(sb.toString());
                m = reservedPattern.matcher(text);
                while (m.find()) {
                    doc.setCharacterAttributes(m.start(), m.end() - m.start(), resAttr, false);
                }

                // 5. Puntuación
                for (int idx = 0; idx < text.length(); idx++) {
                    char ch = text.charAt(idx);
                    if ("{}()[];,.+-*/=<>!:".indexOf(ch) >= 0) {
                        doc.setCharacterAttributes(idx, 1, punctAttr, false);
                    }
                }
                // 6. Resaltado persistente de errores en rojo
                if (Repositorio.errores != null && !Repositorio.errores.isEmpty()) {
                    SimpleAttributeSet errorAttr = new SimpleAttributeSet();
                    StyleConstants.setBackground(errorAttr, new Color(255, 180, 180)); // Fondo rojizo
                    StyleConstants.setForeground(errorAttr, new Color(150, 0, 0));     // Texto rojo oscuro
                    StyleConstants.setUnderline(errorAttr, true);                      // Subrayado
                    StyleConstants.setBold(errorAttr, true);
                    
                    javax.swing.text.Element root = doc.getDefaultRootElement();
                    for (compilerTools.ErrorLSSL err : Repositorio.errores) {
                        int lineIdx = err.getLine() - 1; // getLine() devuelve índice base 1
                        if (lineIdx >= 0 && lineIdx < root.getElementCount()) {
                            javax.swing.text.Element lineElement = root.getElement(lineIdx);
                            int start = lineElement.getStartOffset();
                            int end = lineElement.getEndOffset() - 1;
                            if (end > start) {
                                doc.setCharacterAttributes(start, end - start, errorAttr, false);
                            }
                        }
                    }
                }

            } catch (BadLocationException ex) {
                ex.printStackTrace();
            }
        });
    }

    public static void attachTo(final JTextPane pane) {
        if (pane == null) return;
        final Timer timer = new Timer(300, e -> highlight(pane)); // Delay de 300ms para no saturar
        timer.setRepeats(false);

        pane.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { timer.restart(); }
            @Override public void removeUpdate(DocumentEvent e) { timer.restart(); }
            @Override public void changedUpdate(DocumentEvent e) { timer.restart(); }
        });
        
        // Highlight inicial
        highlight(pane);
    }
}