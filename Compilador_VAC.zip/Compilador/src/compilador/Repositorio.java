package compilador;

import compilerTools.ErrorLSSL;
import compilerTools.Token;
import compilerTools.Production;
import java.util.ArrayList;
import java.util.HashMap;

public class Repositorio {
    // Listas principales
    public static ArrayList<Token> tokens = new ArrayList<>();
    public static ArrayList<ErrorLSSL> errores = new ArrayList<>();
    public static HashMap<String, Symbol> tablaSimbolos = new HashMap<>();
    
    // Listas para capturar producciones sintácticas (Para el semántico)
    public static ArrayList<Production> declaraciones = new ArrayList<>();
    public static ArrayList<Production> constantes = new ArrayList<>();
    public static ArrayList<Production> asignaciones = new ArrayList<>();
    public static ArrayList<Production> funciones = new ArrayList<>();
    
    // Método para limpiar datos en cada nueva compilación
    public static void limpiar() {
        tokens.clear();
        errores.clear();
        tablaSimbolos.clear();
        declaraciones.clear();
        constantes.clear();
        asignaciones.clear();
        funciones.clear();
    }
}